#include "data_header.h"
void filled_up_arrow(int size, int outline_color_choice, int fill_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            for (int columns = size; columns >= rows; columns--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1 || k == rows || rows == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int l = 1; l <= size; l++)
        {
            printf(" ");
            fprintf(fp, " ");
            for (int m = 1; m <= size; m++)
            {
                if (m == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int columns = size; columns >= rows; columns--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1 || k == rows || rows == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int l = 1; l <= size; l++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            printf(" ");
            fprintf(fp, " ");
            for (int m = 1; m <= size; m++)
            {
                if (m == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int columns = size; columns >= rows; columns--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1 || k == rows || rows == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int l = 1; l <= size; l++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            printf(" ");
            fprintf(fp, " ");
            for (int m = 1; m <= size; m++)
            {
                if (m == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void filled_right_arrow(int size, int outline_color_choice, int fill_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            for (int columns = 1; columns <= size; columns++)
            {
                if (rows == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1 || k == rows)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int l = 1; l <= size; l++)
        {
            for (int m = 1; m <= size; m++)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int o = size - 1; o >= l; o--)
            {
                if (o == size - 1 || o == l)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int columns = 1; columns <= size; columns++)
            {
                if (rows == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1 || k == rows)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }

            printf("\n");
            fprintf(fp, "\n");
        }
        for (int l = 1; l <= size; l++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int m = 1; m <= size; m++)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int o = size - 1; o >= l; o--)
            {
                if (o == size - 1 || o == l)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int columns = 1; columns <= size; columns++)
            {
                if (rows == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1 || k == rows)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int l = 1; l <= size; l++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int m = 1; m <= size; m++)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int o = size - 1; o >= l; o--)
            {
                if (o == size - 1 || o == l)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void filled_left_arrow(int size, int outline_color_choice, int fill_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            for (int columns = size; columns >= rows; columns--)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1 || k == rows)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            for (int l = 1; l <= size; l++)
            {
                if (rows == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int m = size - 1; m >= 1; m--)
        {
            for (int o = size; o >= m; o--)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int p = 1; p <= m; p++)
            {
                if (p == 1 || p == m)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int columns = size; columns >= rows; columns--)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1 || k == rows)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            for (int l = 1; l <= size; l++)
            {
                if (rows == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int m = size - 1; m >= 1; m--)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int o = size; o >= m; o--)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int p = 1; p <= m; p++)
            {
                if (p == 1 || p == m)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int columns = size; columns >= rows; columns--)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1 || k == rows)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            for (int l = 1; l <= size; l++)
            {
                if (rows == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int m = size - 1; m >= 1; m--)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int o = size; o >= m; o--)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int p = 1; p <= m; p++)
            {
                if (p == 1 || p == m)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void filled_downward_arrow(int size, int outline_color_choice, int fill_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf(" ");
            fprintf(fp, " ");
            for (int columns = 1; columns <= size; columns++)
            {
                if (columns == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int l = size; l >= 1; l--)
        {
            for (int m = size; m >= l; m--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int o = 1; o <= l; o++)
            {
                if (o == 1 || o == l || l == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            printf(" ");
            fprintf(fp, " ");
            for (int columns = 1; columns <= size; columns++)
            {
                if (columns == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int l = size; l >= 1; l--)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int m = size; m >= l; m--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int o = 1; o <= l; o++)
            {
                if (o == 1 || o == l || l == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            printf(" ");
            fprintf(fp, " ");
            for (int columns = 1; columns <= size; columns++)
            {
                if (columns == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int l = size; l >= 1; l--)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int m = size; m >= l; m--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int o = 1; o <= l; o++)
            {
                if (o == 1 || o == l || l == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice);
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void hollow_up_arrow(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            for (int columns = size; columns >= rows; columns--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1 || k == rows || rows == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int l = 1; l <= size; l++)
        {
            printf(" ");
            fprintf(fp, " ");
            for (int m = 1; m <= size; m++)
            {
                if (m == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int columns = size; columns >= rows; columns--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1 || k == rows || rows == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int l = 1; l <= size; l++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            printf(" ");
            for (int m = 1; m <= size; m++)
            {
                if (m == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int columns = size; columns >= rows; columns--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1 || k == rows || rows == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int l = 1; l <= size; l++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            printf(" ");
            fprintf(fp, " ");
            for (int m = 1; m <= size; m++)
            {
                if (m == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void hollow_downward_arrow(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf(" ");
            fprintf(fp, " ");
            for (int columns = 1; columns <= size; columns++)
            {
                if (columns == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int l = size; l >= 1; l--)
        {
            for (int m = size; m >= l; m--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int o = 1; o <= l; o++)
            {
                if (o == 1 || o == l || l == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            printf(" ");
            fprintf(fp, " ");
            for (int columns = 1; columns <= size; columns++)
            {
                if (columns == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int l = size; l >= 1; l--)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int m = size; m >= l; m--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int o = 1; o <= l; o++)
            {
                if (o == 1 || o == l || l == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            printf(" ");
            fprintf(fp, " ");
            for (int columns = 1; columns <= size; columns++)
            {
                if (columns == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int l = size; l >= 1; l--)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int m = size; m >= l; m--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int o = 1; o <= l; o++)
            {
                if (o == 1 || o == l || l == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void hollow_right_arrow(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            for (int columns = 1; columns <= size; columns++)
            {
                if (rows == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1 || k == rows)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int l = 1; l <= size; l++)
        {
            for (int m = 1; m <= size; m++)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int o = size - 1; o >= l; o--)
            {
                if (o == size - 1 || o == l)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int columns = 1; columns <= size; columns++)
            {
                if (rows == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1 || k == rows)
                {
                    changeTextColor(outline_color_choice);
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }

        for (int l = 1; l <= size; l++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int m = 1; m <= size; m++)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int o = size - 1; o >= l; o--)
            {
                if (o == size - 1 || o == l)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int columns = 1; columns <= size; columns++)
            {
                if (rows == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1 || k == rows)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int l = 1; l <= size; l++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int m = 1; m <= size; m++)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int o = size - 1; o >= l; o--)
            {
                if (o == size - 1 || o == l)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void hollow_left_arrow(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            for (int columns = size; columns >= rows; columns--)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1 || k == rows)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            for (int l = 1; l <= size; l++)
            {
                if (rows == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int m = size - 1; m >= 1; m--)
        {
            for (int o = size; o >= m; o--)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int p = 1; p <= m; p++)
            {
                if (p == 1 || p == m)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int columns = size; columns >= rows; columns--)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1 || k == rows)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            for (int l = 1; l <= size; l++)
            {
                if (rows == size)
                {
                    changeTextColor(outline_color_choice);
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int m = size - 1; m >= 1; m--)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int o = size; o >= m; o--)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int p = 1; p <= m; p++)
            {
                if (p == 1 || p == m)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int columns = size; columns >= rows; columns--)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1 || k == rows)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            for (int l = 1; l <= size; l++)
            {
                if (rows == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int m = size - 1; m >= 1; m--)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int o = size; o >= m; o--)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int p = 1; p <= m; p++)
            {
                if (p == 1 || p == m)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void simple_filled_triangle(int size, int outline_color_choice, int fill_color_choice, char character, int position);
void simple_hollow_triangle(int size, int outline_color_choice, char character, int position);
void inverted_filled_triangle(int size, int outline_color_choice, int fill_color_choice, char character, int position);
void inverted_hollow_triangle(int size, int outline_color_choice, char character, int position);
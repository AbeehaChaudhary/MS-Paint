#include "data_header.h"
void horizontal_line(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 1; row <= size; row++)
        {
            for (int col = 1; col <= size; col++)
            {
                if (row == 1)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        // declaring coordinates for position of the shape
        int x = 60;
        int y = 10;
        for (int row = 1; row <= size; row++)
        {
            gotoxy(x, y);
            for (int col = 1; col <= size; col++)
            {
                if (row == 1)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
            }
            y++;
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        // declaring coordinates for position of the shape

        int x = 120;
        int y = 10;
        for (int row = 1; row <= size; row++)
        {
            gotoxy(x, y);
            for (int col = 1; col <= size; col++)
            {
                if (row == 1)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
            }
            y++;
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void vertical_line(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 0; row < size; row++)
        {
            changeTextColor(outline_color_choice); // outline color function
            printf("%c\n", character);
            fprintf(fp, "%c\n", character);
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        // declaring coordinates for position of the shape
        int x = 60;
        int y = 10;
        for (int row = 0; row < size; row++)
        {
            gotoxy(x, y);
            changeTextColor(outline_color_choice); // outline color function
            printf("%c\n", character);
            fprintf(fp, "%c\n", character);
            y++;
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        // declaring coordinates for position of the shape
        int x = 120;
        int y = 10;
        for (int row = 0; row < size; row++)
        {
            gotoxy(x, y);
            changeTextColor(outline_color_choice); // outline color function
            printf("%c\n", character);
            fprintf(fp, "%c\n", character);
            y++;
        }
        fclose(fp);
    }
}
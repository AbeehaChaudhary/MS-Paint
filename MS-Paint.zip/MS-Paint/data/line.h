void horizontal_line(int size, int outline_color_choice, char character, int position);
void vertical_line(int size, int outline_color_choice, char character, int position);
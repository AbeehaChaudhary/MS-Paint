void filled_oval(int size, int outline_color_choice, char character, int position);
void hollow_oval(int size, int outline_color_choice, char character, int position);

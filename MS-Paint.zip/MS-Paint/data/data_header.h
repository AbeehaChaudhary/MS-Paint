#ifndef DATA_HEADER_FILE
#define DATA_HEADER_FILE

#include "alphabets.h"
#include "numbers.h"
#include "chatbox.h"
#include "pentagon.h"
#include "square.h"
#include "line.h"
#include "rectangle.h"
#include "parallelogram.h"
#include "arrows.h"
#include "hut.h"
#include "triangle.h"
#include "kite.h"
#include "diamond.h"
#include "hexagon.h"
#include "oval.h"
#include "trapezium.h"
#include "heart.h"
#include "position.h"
#include "change_text_color.h"

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <conio.h>
#include <dirent.h>
#include <stdlib.h>
#include <windows.h>

#endif
void filled_up_arrow(int size, int outline_color_choice, int fill_color_choice, char character, int position);
void filled_right_arrow(int size, int outline_color_choice, int fill_color_choice, char character, int position);
void filled_left_arrow(int size, int outline_color_choice, int fill_color_choice, char character, int position);
void filled_downward_arrow(int size, int outline_color_choice, int fill_color_choice, char character, int position);
void hollow_up_arrow(int size, int outline_color_choice, char character, int position);
void hollow_right_arrow(int size, int outline_color_choice, char character, int position);
void hollow_downward_arrow(int size, int outline_color_choice, char character, int position);
void hollow_left_arrow(int size, int outline_color_choice, char character, int position);
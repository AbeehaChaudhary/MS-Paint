#include "data_header.h"
void alphabetA(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            for (int space = size; space >= rows; space--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int column = 1; column <= rows; column++)
            {
                if (column == 1 || column == rows || rows == size - 2)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int space = size; space >= rows; space--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int column = 1; column <= rows; column++)
            {
                if (column == 1 || column == rows || rows == size - 2)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }

            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {

        for (int rows = 1; rows <= size; rows++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int space = size; space >= rows; space--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int column = 1; column <= rows; column++)
            {
                if (column == 1 || column == rows || rows == size - 2)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }

            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void alphabetB(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 0; row < size; row++)
        {
            for (int column = 0; column < size; column++)
            {
                if (row == 0 || row == size - 1 || column == 0 || column == size - 1 || (row == size / 2 && column > 0 && column < size - 1))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {

        for (int row = 0; row < size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int column = 0; column < size; column++)
            {
                if (row == 0 || row == size - 1 || column == 0 || column == size - 1 || (row == size / 2 && column > 0 && column < size - 1))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int column = 0; column < size; column++)
            {
                if (row == 0 || row == size - 1 || column == 0 || column == size - 1 || (row == size / 2 && column > 0 && column < size - 1))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void alphabetC(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 0; row < size; row++)
        {
            for (int column = 0; column < size; column++)
            {
                if ((row == 0 || row == size - 1) || (column == 0))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int column = 0; column < size; column++)
            {
                if ((row == 0 || row == size - 1) || (column == 0))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int column = 0; column < size; column++)
            {
                if ((row == 0 || row == size - 1) || (column == 0))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void alphabetD(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 0; row < size; row++)
        {
            for (int column = 0; column < size; column++)
            {
                if (column == 0 || row == 0 || row == size - 1 || column == size - 1)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "% c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int column = 0; column < size; column++)
            {
                if (column == 0 || row == 0 || row == size - 1 || column == size - 1)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int column = 0; column < size; column++)
            {
                if (column == 0 || row == 0 || row == size - 1 || column == size - 1)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void alphabetE(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 0; row < size; row++)
        {
            for (int column = 0; column < size; column++)
            {
                if (row == 0 || row == size - 1 || column == 0 || (row == size / 2))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int column = 0; column < size; column++)
            {
                if (row == 0 || row == size - 1 || column == 0 || (row == size / 2))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int column = 0; column < size; column++)
            {
                if (row == 0 || row == size - 1 || column == 0 || (row == size / 2))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void alphabetF(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 0; row < size; row++)
        {
            for (int column = 0; column < size; column++)
            {
                if (row == 0 || column == 0 || (row == size / 2))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int column = 0; column < size; column++)
            {
                if (row == 0 || column == 0 || (row == size / 2))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int column = 0; column < size; column++)
            {
                if (row == 0 || column == 0 || (row == size / 2))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void alphabetG(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 0; row < size; row++)
        {
            for (int column = 0; column < size; column++)
            {
                if ((row == 0 || row == size - 1) || column == 0 || (column == size - 1 && row >= size / 2) || (row == size / 2 && column >= size / 2))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int column = 0; column < size; column++)
            {
                if ((row == 0 || row == size - 1) || column == 0 || (column == size - 1 && row >= size / 2) || (row == size / 2 && column >= size / 2))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int column = 0; column < size; column++)
            {
                if ((row == 0 || row == size - 1) || column == 0 || (column == size - 1 && row >= size / 2) || (row == size / 2 && column >= size / 2))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void alphabetH(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position = 1)
    {
        for (int row = 0; row < size; row++)
        {
            for (int column = 0; column < size; column++)
            {
                if (column == 0 || column == size - 1 || row == size / 2)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int column = 0; column < size; column++)
            {
                if (column == 0 || column == size - 1 || row == size / 2)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int column = 0; column < size; column++)
            {
                if (column == 0 || column == size - 1 || row == size / 2)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void alphabetI(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 0; row < size; row++)
        {
            for (int column = 0; column < size; column++)
            {
                if (row == 0 || row == size - 1 || column == size / 2)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int column = 0; column < size; column++)
            {
                if (row == 0 || row == size - 1 || column == size / 2)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int column = 0; column < size; column++)
            {
                if (row == 0 || row == size - 1 || column == size / 2)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void alphabetJ(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 0; row < size; row++)
        {
            for (int column = 0; column < size; column++)
            {
                if (column == ((size - 1) / 2) || row == 0 || (row == size - 1 && (column < ((size - 1) / 2))) || (column == 0 && (row == size - 2)))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int column = 0; column < size; column++)
            {
                if (column == ((size - 1) / 2) || row == 0 || (row == size - 1 && (column < ((size - 1) / 2))) || (column == 0 && (row == size - 2)))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int column = 0; column < size; column++)
            {
                if (column == ((size - 1) / 2) || row == 0 || (row == size - 1 && (column < ((size - 1) / 2))) || (column == 0 && (row == size - 2)))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void alphabetK(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 0; row < size; row++)
        {
            for (int column = size; column > row; column--)
            {
                if (column == size || column == row + 1)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int row = 1; row < size; row++)
        {
            for (int column = 0; column <= row; column++)
            {
                if (column == 0 || column == row)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int column = size; column > row; column--)
            {
                if (column == size || column == row + 1)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int row = 1; row < size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int column = 0; column <= row; column++)
            {
                if (column == 0 || column == row)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int column = size; column > row; column--)
            {
                if (column == size || column == row + 1)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int row = 1; row < size; row++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int column = 0; column <= row; column++)
            {
                if (column == 0 || column == row)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void alphabetL(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 0; row < size; row++)
        {
            for (int column = 0; column < size; column++)
            {
                if (column == 0 || row == size - 1)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int column = 0; column < size; column++)
            {
                if (column == 0 || row == size - 1)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int column = 0; column < size; column++)
            {
                if (column == 0 || row == size - 1)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void alphabetM(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 0; row < size; row++)
        {
            for (int column = 0; column < size; column++)
            {
                if (column == 0 || column == size - 1 || (row <= (size - 1) / 2 && (row == column || column == (size - 1) - row)))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int column = 0; column < size; column++)
            {
                if (column == 0 || column == size - 1 || (row <= (size - 1) / 2 && (row == column || column == (size - 1) - row)))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int column = 0; column < size; column++)
            {
                if (column == 0 || column == size - 1 || (row <= (size - 1) / 2 && (row == column || column == (size - 1) - row)))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void alphabetN(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 0; row < size; row++)
        {
            for (int column = 0; column < size; column++)
            {
                if (column == 0 || column == size - 1 || row == column)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int column = 0; column < size; column++)
            {
                if (column == 0 || column == size - 1 || row == column)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int column = 0; column < size; column++)
            {
                if (column == 0 || column == size - 1 || row == column)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void alphabetO(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 0; row < size; row++)
        {
            for (int column = 0; column < size; column++)
            {
                if (row == 0 && (column > 0 && column < size - 1) || row == size - 1 && (column > 0 && column < size - 1) || column == 0 && (row > 0 && row < size - 1) || column == size - 1 && (row > 0 && row < size - 1))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int column = 0; column < size; column++)
            {
                if (row == 0 && (column > 0 && column < size - 1) || row == size - 1 && (column > 0 && column < size - 1) || column == 0 && (row > 0 && row < size - 1) || column == size - 1 && (row > 0 && row < size - 1))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int column = 0; column < size; column++)
            {
                if (row == 0 && (column > 0 && column < size - 1) || row == size - 1 && (column > 0 && column < size - 1) || column == 0 && (row > 0 && row < size - 1) || column == size - 1 && (row > 0 && row < size - 1))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void alphabetP(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 0; row < size; row++)
        {
            for (int column = 0; column < size; column++)
            {
                if (column == 0 || row == size - 3 || row == 0 || (column == size - 1 && (row < column - 1)))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int column = 0; column < size; column++)
            {
                if (column == 0 || row == size - 3 || row == 0 || (column == size - 1 && (row < column - 1)))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int column = 0; column < size; column++)
            {
                if (column == 0 || row == size - 3 || row == 0 || (column == size - 1 && (row < column - 1)))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void alphabetQ(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 0; row < size + size / 2; row++)
        {
            for (int column = 0; column < size + size / 2; column++)
            {
                if (row == 0 && column < size || column == 0 && row < size || row == size - 1 && column < size || column == size - 1 && row < size || (row == column && (row >= size / 2)))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = 0; row < size + size / 2; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int column = 0; column < size + size / 2; column++)
            {
                if (row == 0 && column < size || column == 0 && row < size || row == size - 1 && column < size || column == size - 1 && row < size || (row == column && (row >= size / 2)))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = 0; row < size + size / 2; row++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int column = 0; column < size + size / 2; column++)
            {
                if (row == 0 && column < size || column == 0 && row < size || row == size - 1 && column < size || column == size - 1 && row < size || (row == column && (row >= size / 2)))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void alphabetR(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 0; row < size; row++)
        {
            for (int column = 0; column < size; column++)
            {
                if (column == 0 || (row == 0 && column < size) || row == 3 && (column < size) || (column == (size - 1) && row > 0 && row < size - 3) || row - column == 2)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // mmiddle
    if (position == 2)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int column = 0; column < size; column++)
            {
                if (column == 0 || (row == 0 && column < size) || row == 3 && (column < size) || (column == (size - 1) && row > 0 && row < size - 3) || row - column == 2)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = 0; row < size; row++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int column = 0; column < size; column++)
            {
                if (column == 0 || (row == 0 && column < size) || row == 3 && (column < size) || (column == (size - 1) && row > 0 && row < size - 3) || row - column == 2)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void alphabetS(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 1; row <= size; row++)
        {
            for (int column = 1; column <= size; column++)
            {
                if ((row == 1 || row == size || row == size / 2 + 1) || (row <= size / 2 && column == 1) || (row > size / 2 && column == size))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = 1; row <= size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int column = 1; column <= size; column++)
            {
                if ((row == 1 || row == size || row == size / 2 + 1) || (row <= size / 2 && column == 1) || (row > size / 2 && column == size))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = 1; row <= size; row++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int column = 1; column <= size; column++)
            {
                if ((row == 1 || row == size || row == size / 2 + 1) || (row <= size / 2 && column == 1) || (row > size / 2 && column == size))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void alphabetT(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 1; row <= size; row++)
        {
            for (int column = 1; column <= size; column++)
            {
                if (row == 1 || column == size / 2 + 1)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = 1; row <= size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int column = 1; column <= size; column++)
            {
                if (row == 1 || column == size / 2 + 1)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = 1; row <= size; row++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int column = 1; column <= size; column++)
            {
                if (row == 1 || column == size / 2 + 1)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void alphabetU(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 1; row <= size; row++)
        {
            for (int column = 1; column <= size; column++)
            {
                if ((column == 1 && row != size) || (column == size && row != size) || (row == size && column != 1 && column != size))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = 1; row <= size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int column = 1; column <= size; column++)
            {
                if ((column == 1 && row != size) || (column == size && row != size) || (row == size && column != 1 && column != size))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = 1; row <= size; row++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int column = 1; column <= size; column++)
            {
                if ((column == 1 && row != size) || (column == size && row != size) || (row == size && column != 1 && column != size))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void alphabetV(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 1; row <= size; row++)
        {
            for (int column = 1; column <= size * 2 - 1; column++)
            {
                if (column == row || column == size * 2 - row)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = 1; row <= size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int column = 1; column <= size * 2 - 1; column++)
            {
                if (column == row || column == size * 2 - row)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = 1; row <= size; row++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int column = 1; column <= size * 2 - 1; column++)
            {
                if (column == row || column == size * 2 - row)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void alphabetW(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 1; row <= size; row++)
        {
            for (int column = 1; column <= size * 2; column++)
            {
                if (column == 1 || column == size * 2 || (row + column) == (size + 1) || (column - row) == size)
                {

                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = 1; row <= size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int column = 1; column <= size * 2; column++)
            {
                if (column == 1 || column == size * 2 || (row + column) == (size + 1) || (column - row) == size)
                {

                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = 1; row <= size; row++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int column = 1; column <= size * 2; column++)
            {
                if (column == 1 || column == size * 2 || (row + column) == (size + 1) || (column - row) == size)
                {

                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void alphabetX(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 1; row <= size; row++)
        {
            for (int column = 1; column <= size; column++)
            {
                if (row == column || column == (size - row + 1))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = 1; row <= size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int column = 1; column <= size; column++)
            {
                if (row == column || column == (size - row + 1))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = 1; row <= size; row++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int column = 1; column <= size; column++)
            {
                if (row == column || column == (size - row + 1))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void alphabetY(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 1; row <= size; row++)
        {
            for (int column = 1; column <= size; column++)
            {
                if (row + column == size + 1 || row == column && row <= size / 2)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = 1; row <= size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int column = 1; column <= size; column++)
            {
                if (row + column == size + 1 || row == column && row <= size / 2)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = 1; row <= size; row++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int column = 1; column <= size; column++)
            {
                if (row + column == size + 1 || row == column && row <= size / 2)
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void alphabetZ(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 1; row <= size; row++)
        {
            for (int column = 1; column <= size; column++)
            {
                if (row == 1 || row == size || column == (size - row + 1))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = 1; row <= size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int column = 1; column <= size; column++)
            {
                if (row == 1 || row == size || column == (size - row + 1))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = 1; row <= size; row++)
        {
            printf("                                                                                                                ");
            fprintf(fp, "                                                                                                                ");
            for (int column = 1; column <= size; column++)
            {
                if (row == 1 || row == size || column == (size - row + 1))
                {
                    changeTextColor(outline_color_choice); // color function
                    printf("%c ", character);
                    fprintf(fp, "%c ", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
#include "data_header.h"
void filled_oval(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 1; row <= size; row++)
        {
            for (int column = 1; column <= size; column++)
            {
                if ((column == 1 && row < 3) || (column == size && row < 3) || (row == size && column < 3) || (row == size && column >= size - 1) || (row == 2 && column < 2) ||
                    (row == 2 && column > size - 1) || (row == size - 1 && column < 2) || (row == size - 1 && column > size - 1) || (row == 1 && column < 3) || (row == 1 && column >= size - 1))
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
                else
                {
                    changeTextColor(outline_color_choice);
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        // declaraing coordinates for position of the shape
        int x = 60;
        int y = 10;
        for (int row = 1; row <= size; row++)
        {
            gotoxy(x, y);
            for (int column = 1; column <= size; column++)
            {
                if ((column == 1 && row < 3) || (column == size && row < 3) || (row == size && column < 3) || (row == size && column >= size - 1) || (row == 2 && column < 2) ||
                    (row == 2 && column > size - 1) || (row == size - 1 && column < 2) || (row == size - 1 && column > size - 1) || (row == 1 && column < 3) || (row == 1 && column >= size - 1))
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
                else
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
            }
            y++;
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        // declaring coordinates for position of the shape
        int x = 120;
        int y = 10;
        for (int row = 1; row <= size; row++)
        {
            gotoxy(x, y);
            for (int column = 1; column <= size; column++)
            {
                if ((column == 1 && row < 3) || (column == size && row < 3) || (row == size && column < 3) || (row == size && column >= size - 1) || (row == 2 && column < 2) ||
                    (row == 2 && column > size - 1) || (row == size - 1 && column < 2) || (row == size - 1 && column > size - 1) || (row == 1 && column < 3) || (row == 1 && column >= size - 1))
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
                else
                {
                    changeTextColor(outline_color_choice); // outlinr color function
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
            }
            y++;
            printf("\n");
            fprintf(fp, "\n");
        }
    }
    fclose(fp);
}
void hollow_oval(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 1; row <= size; row++)
        {
            for (int column = 1; column <= size; column++)
            {
                if ((row == 1 && column > 2 && column <= size - 2) || (row == size && column > 2 && column <= size - 2) || (column == 1 && row > 2 && row <= size - 2) ||
                    (column == size && row > 2 && row <= size - 2) || (row == 2 && column > 1 && column < 3) || (row == 2 && column <= size - 1 && column > size - 2) ||
                    (row == size - 1 && column > 1 && column < 3) || (row == size - 1 && column <= size - 1 && column > size - 2))
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        // declaraing coordinates for position of the shape
        int x = 60;
        int y = 10;
        for (int row = 1; row <= size; row++)
        {
            gotoxy(x, y);
            for (int column = 1; column <= size; column++)
            {
                if ((row == 1 && column > 2 && column <= size - 2) || (row == size && column > 2 && column <= size - 2) || (column == 1 && row > 2 && row <= size - 2) ||
                    (column == size && row > 2 && row <= size - 2) || (row == 2 && column > 1 && column < 3) || (row == 2 && column <= size - 1 && column > size - 2) ||
                    (row == size - 1 && column > 1 && column < 3) || (row == size - 1 && column <= size - 1 && column > size - 2))
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            y++;
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        // declaring coordinates for position of the shape
        int x = 120;
        int y = 10;
        for (int row = 1; row <= size; row++)
        {
            gotoxy(x, y);
            for (int column = 1; column <= size; column++)
            {
                if ((row == 1 && column > 2 && column <= size - 2) || (row == size && column > 2 && column <= size - 2) || (column == 1 && row > 2 && row <= size - 2) ||
                    (column == size && row > 2 && row <= size - 2) || (row == 2 && column > 1 && column < 3) || (row == 2 && column <= size - 1 && column > size - 2) ||
                    (row == size - 1 && column > 1 && column < 3) || (row == size - 1 && column <= size - 1 && column > size - 2))
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            y++;
            printf("\n");
            fprintf(fp, "\n");
        }
    }
    fclose(fp);
}
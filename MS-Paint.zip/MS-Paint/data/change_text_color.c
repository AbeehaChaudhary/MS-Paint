#include "data_header.h"
void changeTextColor(int color)
{
    printf("\033[1;%dm", color);
}
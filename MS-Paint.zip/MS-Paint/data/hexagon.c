#include "data_header.h"
void filled_hexagon(int size, int outline_color_choice, int fill_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            for (int columns = size; columns >= rows; columns--)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1 || k == rows)
                {
                    changeTextColor(outline_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int l = 1; l <= size + 1; l++)
        {
            for (int o = 0; o <= size; o++)
            {
                if (o == 0 || o == size)
                {
                    changeTextColor(outline_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int p = size; p >= 1; p--)
        {
            for (int q = size; q >= p; q--)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int r = 1; r <= p; r++)
            {
                if (r == 1 || r == p)
                {
                    changeTextColor(outline_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf("                                                      ");
            fprintf(fp, "                                                      ");
            for (int columns = size; columns >= rows; columns--)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1 || k == rows)
                {
                    changeTextColor(outline_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int l = 1; l <= size + 1; l++)
        {
            printf("                                                      ");
            fprintf(fp, "                                                      ");
            for (int o = 0; o <= size; o++)
            {
                if (o == 0 || o == size)
                {
                    changeTextColor(outline_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int p = size; p >= 1; p--)
        {
            printf("                                                      ");
            fprintf(fp, "                                                      ");
            for (int q = size; q >= p; q--)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int r = 1; r <= p; r++)
            {
                if (r == 1 || r == p)
                {
                    changeTextColor(outline_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf("                                                                                                                 ");
            fprintf(fp, "                                                                                                                   ");
            for (int columns = size; columns >= rows; columns--)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1 || k == rows)
                {
                    changeTextColor(outline_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int l = 1; l <= size + 1; l++)
        {
            printf("                                                                                                                 ");

            for (int o = 0; o <= size; o++)
            {
                if (o == 0 || o == size)
                {
                    changeTextColor(outline_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int p = size; p >= 1; p--)
        {
            printf("                                                                                                                 ");
            fprintf(fp, "                                                                                                                   ");
            for (int q = size; q >= p; q--)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int r = 1; r <= p; r++)
            {
                if (r == 1 || r == p)
                {
                    changeTextColor(outline_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void hollow_hexagon(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            for (int columns = size; columns >= rows; columns--)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1 || k == rows)
                {
                    changeTextColor(outline_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
                else
                {
                    printf("    ");
                    fprintf(fp, "    ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int l = 1; l <= size + 1; l++)
        {
            for (int o = 0; o <= size; o++)
            {
                if (o == 0 || o == size)
                {
                    changeTextColor(outline_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
                else
                {
                    printf("    ");
                    fprintf(fp, "    ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int p = size; p >= 1; p--)
        {
            for (int q = size; q >= p; q--)
            {
                printf("  ");
            }
            for (int r = 1; r <= p; r++)
            {
                if (r == 1 || r == p)
                {
                    changeTextColor(outline_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
                else
                {
                    printf("    ");
                    fprintf(fp, "    ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 2)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf("                                                      ");
            fprintf(fp, "                                                      ");
            for (int columns = size; columns >= rows; columns--)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1 || k == rows)
                {
                    changeTextColor(outline_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
                else
                {
                    printf("    ");
                    fprintf(fp, "    ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int l = 1; l <= size + 1; l++)
        {
            printf("                                                      ");
            fprintf(fp, "                                                      ");
            for (int o = 0; o <= size; o++)
            {
                if (o == 0 || o == size)
                {
                    changeTextColor(outline_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
                else
                {
                    printf("    ");
                    fprintf(fp, "    ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int p = size; p >= 1; p--)
        {
            printf("                                                      ");
            fprintf(fp, "                                                      ");
            for (int q = size; q >= p; q--)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int r = 1; r <= p; r++)
            {
                if (r == 1 || r == p)
                {
                    changeTextColor(outline_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
                else
                {
                    printf("    ");
                    fprintf(fp, "    ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf("                                                                                                                   ");
            fprintf(fp, "                                                                                                                   ");
            for (int columns = size; columns >= rows; columns--)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1 || k == rows)
                {
                    changeTextColor(outline_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
                else
                {
                    printf("    ");
                    fprintf(fp, "    ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int l = 1; l <= size + 1; l++)
        {
            printf("                                                                                                                   ");
            fprintf(fp, "                                                                                                                   ");
            for (int o = 0; o <= size; o++)
            {
                if (o == 0 || o == size)
                {
                    changeTextColor(outline_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
                else
                {
                    printf("    ");
                    fprintf(fp, "    ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int p = size; p >= 1; p--)
        {
            printf("                                                                                                                   ");
            fprintf(fp, "                                                                                                                   ");
            for (int q = size; q >= p; q--)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int r = 1; r <= p; r++)
            {
                if (r == 1 || r == p)
                {
                    changeTextColor(outline_color_choice);
                    printf("   %c", character);
                    fprintf(fp, "   %c", character);
                }
                else
                {
                    printf("    ");
                    fprintf(fp, "    ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void filled_heart(int size, int outline_color_choice, int fill_color_choice, char character, int position);
void hollow_heart(int size, int outline_color_choice, char character, int position);
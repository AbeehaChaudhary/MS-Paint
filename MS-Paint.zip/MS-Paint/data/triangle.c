#include "data_header.h"
void simple_filled_triangle(int size, int outline_color_choice, int fill_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int rows = 1; rows <= size; rows++) 
        {
            for (int space = size; space >= rows; space--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int column = 1; column <= rows; column++)
            {
                if (column == 1 || column == rows || rows == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        // declaring coordinates for position of the shape
        int x = 60;
        int y = 10;
        for (int rows = 1; rows <= size; rows++)
        {
            gotoxy(x, y);
            for (int space = size; space >= rows; space--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int column = 1; column <= rows; column++)
            {
                if (column == 1 || column == rows || rows == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            y++;
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        // declaring coordinates for position of the shape
        int x = 120;
        int y = 10;
        for (int rows = 1; rows <= size; rows++)
        {
            gotoxy(x, y);
            for (int space = size; space >= rows; space--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int column = 1; column <= rows; column++)
            {
                if (column == 1 || column == rows || rows == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            y++;
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void simple_hollow_triangle(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            for (int space = size; space >= rows; space--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int column = 1; column <= rows; column++)
            {
                if (column == 1 || column == rows || rows == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        // declaring coordinates for position of the shape
        int x = 60;
        int y = 10;
        for (int rows = 1; rows <= size; rows++)
        {
            gotoxy(x, y);
            for (int space = size; space >= rows; space--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int column = 1; column <= rows; column++)
            {
                if (column == 1 || column == rows || rows == size)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            y++;
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        // declaring coordinates for position of the shape
        int x = 120;
        int y = 10;
        for (int rows = 1; rows <= size; rows++)
        {
            gotoxy(x, y);
            for (int space = size; space >= rows; space--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int column = 1; column <= rows; column++)
            {
                if (column == 1 || column == rows || rows == size)
                {
                    changeTextColor(outline_color_choice); // ouline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            y++;
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void inverted_filled_triangle(int size, int outline_color_choice, int fill_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = size; row >= 1; row--)
        {
            for (int column = 0; column < size - row; column++)
            {
                printf("  ");
                fprintf(fp, "  ");
            }

            for (int column = 0; column < 2 * row - 1; column++)
            {
                if (row == size || row == 1 || column == (row * 2 - 1) - 1 || column == 0)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        // declaring coordinates for position of the shape
        int x = 60;
        int y = 10;
        for (int row = size; row >= 1; row--)
        {
            gotoxy(x, y);
            for (int column = 0; column < size - row; column++)
            {
                printf("  ");
                fprintf(fp, "  ");
            }

            for (int column = 0; column < 2 * row - 1; column++)
            {
                if (row == size || row == 1 || column == (row * 2 - 1) - 1 || column == 0)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            y++;
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        // declaring coordinates for position of the shape
        int x = 120;
        int y = 10;
        for (int row = size; row >= 1; row--)
        {
            gotoxy(x, y);
            for (int column = 0; column < size - row; column++)
            {
                printf("  ");
                fprintf(fp, "  ");
            }

            for (int column = 0; column < 2 * row - 1; column++)
            {
                if (row == size || row == 1 || column == (row * 2 - 1) - 1 || column == 0)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            y++;
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void inverted_hollow_triangle(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = size; row >= 1; row--)
        {
            for (int column = 0; column < size - row; column++)
            {
                printf("  ");
                fprintf(fp, "  ");
            }

            for (int column = 0; column < 2 * row - 1; column++)
            {
                if (row == size || row == 1 || column == (row * 2 - 1) - 1 || column == 0)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        // declaring coordinates for position of the shape
        int x = 60;
        int y = 10;
        for (int row = size; row >= 1; row--)
        {
            gotoxy(x, y);
            for (int column = 0; column < size - row; column++)
            {
                printf("  ");
                fprintf(fp, "  ");
            }

            for (int column = 0; column < 2 * row - 1; column++)
            {
                if (row == size || row == 1 || column == (row * 2 - 1) - 1 || column == 0)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            y++;
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        // declaring coordinates for position of the shape
        int x = 110;
        int y = 10;
        for (int row = size; row >= 1; row--)
        {
            gotoxy(x, y);
            for (int column = 0; column < size - row; column++)
            {
                printf("  ");
                fprintf(fp, "  ");
            }

            for (int column = 0; column < 2 * row - 1; column++)
            {
                if (row == size || row == 1 || column == (row * 2 - 1) - 1 || column == 0)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            y++;
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
#include "data_header.h"
void filled_square(int size, int outline_color_choice, int fill_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL) 
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 0; row < size; row++)
        {
            for (int column = 0; column < size; column++)
            {
                if (row == size - 1 || row == 0 || column == 0 || column == size - 1)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c ", character);
                    fprintf(fp, " %c ", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c ", character);
                    fprintf(fp, " %c ", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        // declaring coordinates for position of the shape
        int x = 60;
        int y = 10;
        for (int row = 0; row < size; row++)
        {
            gotoxy(x, y);
            for (int column = 0; column < size; column++)
            {
                if (row == size - 1 || row == 0 || column == 0 || column == size - 1)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c ", character);
                    fprintf(fp, " %c ", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c ", character);
                    fprintf(fp, " %c ", character);
                }
            }
            y++;
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        // declaring coordinates for position of the shape
        int x = 120;
        int y = 10;
        for (int row = 0; row < size; row++)
        {
            gotoxy(x, y);

            for (int column = 0; column < size; column++)
            {
                if (row == size - 1 || row == 0 || column == 0 || column == size - 1)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c ", character);
                    fprintf(fp, " %c ", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c ", character);
                    fprintf(fp, " %c ", character);
                }
            }
            y++;
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void hollow_square(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = 0; row < size; row++)
        {
            for (int column = 0; column < size; column++)
            {
                if (row == size - 1 || row == 0 || column == 0 || column == size - 1)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c ", character);
                     fprintf(fp, " %c ", character);
                }
                else
                {
                    printf("   ");
                    fprintf(fp, "   ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        // declaring coordinates for position of the shape
        int x = 60;
        int y = 10;
        for (int row = 0; row < size; row++)
        {
            gotoxy(x, y);
            for (int column = 0; column < size; column++)
            {
                if (row == size - 1 || row == 0 || column == 0 || column == size - 1)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c ", character);
                     fprintf(fp, " %c ", character);
                }
                else
                {
                    printf("   ");
                    fprintf(fp, "   ");
                }
            }
            y++;
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        // declaring coordinates for position of the shape
        int x = 120;
        int y = 10;
        for (int row = 0; row < size; row++)
        {
            gotoxy(x, y);
            for (int column = 0; column < size; column++)
            {
                if (row == size - 1 || row == 0 || column == 0 || column == size - 1)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c ", character);
                    fprintf(fp, " %c ", character);
                }
                else
                {
                    printf("   ");
                    fprintf(fp, "   ");
                }
            }
            y++;
            printf("\n");
            fprintf(fp, "\n");
        }
    }
    fclose(fp);
}
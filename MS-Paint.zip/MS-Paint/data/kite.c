#include "data_header.h"
void filled_kite(int size, int outline_color_choice, int fill_color_choice, char character, int position)
{
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            for (int columns = size; columns >= rows; columns--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
            }
            for (int l = 2; l <= rows; l++)
            {
                if (l == rows)
                {
                    changeTextColor(outline_color_choice); // utline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int rows = size + 1; rows >= 1; rows--)
        {
            for (int columns = size; columns >= rows; columns--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
            }
            for (int l = 2; l <= rows; l++)
            {
                if (l == rows)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int rows = 1; rows <= size / 2; rows++)
        {
            for (int columns = size; columns >= rows; columns--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (rows == size / 2 || k == 1)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
            }
            for (int l = 2; l <= rows; l++)
            {
                if (rows == size / 2 || l == rows)
                {
                    changeTextColor(outline_color_choice); // outline  color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int columns = size; columns >= rows; columns--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
            }
            for (int l = 2; l <= rows; l++)
            {
                if (l == rows)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int rows = size + 1; rows >= 1; rows--)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int columns = size; columns >= rows; columns--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
            }
            for (int l = 2; l <= rows; l++)
            {
                if (l == rows)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int rows = 1; rows <= size / 2; rows++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int columns = size; columns >= rows; columns--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (rows == size / 2 || k == 1)
                {
                    changeTextColor(outline_color_choice); // outline clr func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill clr func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
            }
            for (int l = 2; l <= rows; l++)
            {
                if (rows == size / 2 || l == rows)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf("                                                                                                                    ");
            fprintf(fp, "                                                                                                                    ");
            for (int columns = size; columns >= rows; columns--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
            }
            for (int l = 2; l <= rows; l++)
            {
                if (l == rows)
                {
                    changeTextColor(outline_color_choice);
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice);
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int rows = size + 1; rows >= 1; rows--)
        {
            printf("                                                                                                                    ");
            fprintf(fp, "                                                                                                                    ");
            for (int columns = size; columns >= rows; columns--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
            }
            for (int l = 2; l <= rows; l++)
            {
                if (l == rows)
                {
                    changeTextColor(outline_color_choice);
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice);
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int rows = 1; rows <= size / 2; rows++)
        {
            printf("                                                                                                                    ");
            fprintf(fp, "                                                                                                                    ");
            for (int columns = size; columns >= rows; columns--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (rows == size / 2 || k == 1)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
            }
            for (int l = 2; l <= rows; l++)
            {
                if (rows == size / 2 || l == rows)
                {
                    changeTextColor(outline_color_choice);
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice);
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void hollow_kite(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            for (int columns = size; columns >= rows; columns--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            for (int l = 2; l <= rows; l++)
            {
                if (l == rows)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int rows = size + 1; rows >= 1; rows--)
        {
            for (int columns = size; columns >= rows; columns--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            for (int l = 2; l <= rows; l++)
            {
                if (l == rows)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int rows = 1; rows <= size / 2; rows++)
        {
            for (int columns = size; columns >= rows; columns--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (rows == size / 2 || k == 1)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            for (int l = 2; l <= rows; l++)
            {
                if (rows == size / 2 || l == rows)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int columns = size; columns >= rows; columns--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            for (int l = 2; l <= rows; l++)
            {
                if (l == rows)
                {
                    changeTextColor(outline_color_choice); // outline color
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int rows = size + 1; rows >= 1; rows--)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int columns = size; columns >= rows; columns--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            for (int l = 2; l <= rows; l++)
            {
                if (l == rows)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int rows = 1; rows <= size / 2; rows++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int columns = size; columns >= rows; columns--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (rows == size / 2 || k == 1)
                {
                    changeTextColor(outline_color_choice); // outline  color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            for (int l = 2; l <= rows; l++)
            {
                if (rows == size / 2 || l == rows)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int rows = 1; rows <= size; rows++)
        {
            printf("                                                                                                                    ");
            fprintf(fp, "                                                                                                                    ");
            for (int columns = size; columns >= rows; columns--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            for (int l = 2; l <= rows; l++)
            {
                if (l == rows)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int rows = size + 1; rows >= 1; rows--)
        {
            printf("                                                                                                                    ");
            fprintf(fp, "                                                                                                                    ");
            for (int columns = size; columns >= rows; columns--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (k == 1)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            for (int l = 2; l <= rows; l++)
            {
                if (l == rows)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        for (int rows = 1; rows <= size / 2; rows++)
        {
            printf("                                                                                                                    ");
            fprintf(fp, "                                                                                                                    ");
            for (int columns = size; columns >= rows; columns--)
            {
                printf(" ");
                fprintf(fp, " ");
            }
            for (int k = 1; k <= rows; k++)
            {
                if (rows == size / 2 || k == 1)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            for (int l = 2; l <= rows; l++)
            {
                if (rows == size / 2 || l == rows)
                {
                    changeTextColor(outline_color_choice); // outline color func
                    printf("%c", character);
                    fprintf(fp, "%c", character);
                }
                else
                {
                    printf(" ");
                    fprintf(fp, " ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
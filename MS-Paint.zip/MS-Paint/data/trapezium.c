#include "data_header.h"
void simple_filled_trapezium(int size, int outline_color_choice, int fill_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = size / 2; row < size; row++)
        {
            for (int space = 0; space < size - row; space++)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int column = 0; column < row * 2 - 1; column++)
            {
                if (row == size / 2 || row == size - 1 || column == 0 || column == (row * 2 - 1) - 1)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = size / 2; row < size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int space = 0; space < size - row; space++)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int column = 0; column < row * 2 - 1; column++)
            {
                if (row == size / 2 || row == size - 1 || column == 0 || column == (row * 2 - 1) - 1)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = size / 2; row < size; row++)
        {
            printf("                                                                                                             ");
            fprintf(fp, "                                                                                                             ");
            for (int space = 0; space < size - row; space++)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int column = 0; column < row * 2 - 1; column++)
            {
                if (row == size / 2 || row == size - 1 || column == 0 || column == (row * 2 - 1) - 1)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void simple_hollow_trapezium(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = size / 2; row < size; row++)
        {
            for (int space = 0; space < size - row; space++)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int column = 0; column < row * 2 - 1; column++)
            {
                if (row == size / 2 || row == size - 1 || column == 0 || column == (row * 2 - 1) - 1)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = size / 2; row < size; row++)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int space = 0; space < size - row; space++)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int column = 0; column < row * 2 - 1; column++)
            {
                if (row == size / 2 || row == size - 1 || column == 0 || column == (row * 2 - 1) - 1)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = size / 2; row < size; row++)
        {
            printf("                                                                                                             ");
            fprintf(fp, "                                                                                                             ");
            for (int space = 0; space < size - row; space++)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int column = 0; column < row * 2 - 1; column++)
            {
                if (row == size / 2 || row == size - 1 || column == 0 || column == (row * 2 - 1) - 1)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void inverted_filled_trapezium(int size, int outline_color_choice, int fill_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = size; row >= size / 2; row--)
        {
            for (int space = 0; space < size - row; space++)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int column = 0; column < row * 2 - 1; column++)
            {
                if (row == size / 2 || row == size || column == 0 || column == (row * 2 - 1) - 1)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = size; row >= size / 2; row--)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int space = 0; space < size - row; space++)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int column = 0; column < row * 2 - 1; column++)
            {
                if (row == size / 2 || row == size || column == 0 || column == (row * 2 - 1) - 1)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }

            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = size; row >= size / 2; row--)
        {
            printf("                                                                                                             ");
            fprintf(fp, "                                                                                                             ");
            for (int space = 0; space < size - row; space++)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int column = 0; column < row * 2 - 1; column++)
            {
                if (row == size / 2 || row == size || column == 0 || column == (row * 2 - 1) - 1)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                }
                else
                {
                    changeTextColor(fill_color_choice); // fill color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
void inverted_hollow_trapezium(int size, int outline_color_choice, char character, int position)
{
    // saving the address of file in "fp"
    FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "w");
    if (fp == NULL)
    {
        printf("This file does not exist!\n");
    }
    // left
    if (position == 1)
    {
        for (int row = size; row >= size / 2; row--)
        {
            for (int space = 0; space < size - row; space++)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int column = 0; column < row * 2 - 1; column++)
            {
                if (row == size / 2 || row == size || column == 0 || column == (row * 2 - 1) - 1)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // middle
    if (position == 2)
    {
        for (int row = size; row >= size / 2; row--)
        {
            printf("                                                        ");
            fprintf(fp, "                                                        ");
            for (int space = 0; space < size - row; space++)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int column = 0; column < row * 2 - 1; column++)
            {
                if (row == size / 2 || row == size || column == 0 || column == (row * 2 - 1) - 1)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
    // right
    if (position == 3)
    {
        for (int row = size; row >= size / 2; row--)
        {
            printf("                                                                                                             ");
            fprintf(fp, "                                                                                                             ");
            for (int space = 0; space < size - row; space++)
            {
                printf("  ");
                fprintf(fp, "  ");
            }
            for (int column = 0; column < row * 2 - 1; column++)
            {
                if (row == size / 2 || row == size || column == 0 || column == (row * 2 - 1) - 1)
                {
                    changeTextColor(outline_color_choice); // outline color function
                    printf(" %c", character);
                    fprintf(fp, " %c", character);
                }
                else
                {
                    printf("  ");
                    fprintf(fp, "  ");
                }
            }
            printf("\n");
            fprintf(fp, "\n");
        }
        fclose(fp);
    }
}
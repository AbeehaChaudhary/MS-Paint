void filled_chatbox(int size, int outline_color_choice, int fill_color_choice, char character, int position);
void hollow_chatbox(int size, int outline_color_choice, char character, int position);

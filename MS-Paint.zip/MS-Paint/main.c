#include ".\data\data_header.h"
#include ".\brain\brain_header.h"
#include ".\interface\interface_header.h"

int main()
{
    main_menu();
    return 0;
}
#include "interface_header.h"
void clear_screen()
{
    system("cls");
}
bool file_available(const char *name)
{
    FILE *file = fopen(name, "r");
    if (file)
    {
        fclose(file);
        return true;
    }
    return false;
}
void main_menu()
{
    printf("------------------------------------------------------------------------------------\n");
    printf("|                               Welcome to MS Paint                                |\n");
    printf("------------------------------------------------------------------------------------\n");
    int option, shape;
    char key;
    printf("------------------------------------------------------------------------------------\n");
    printf("|                                   Options                                        |\n");
    printf("------------------------------------------------------------------------------------\n");
    printf("Press 1 to make shapes\n");
    printf("Press 2 to draw on terminal\n");
    printf("Press 3 to save the file\n");
    printf("Press 4 to view existing file\n");
    printf("Press 5 to edit an existing file\n");
    printf("Press q to quit\n");
    scanf("%d", &option);
    // Using a while loop so that the program does not end until the user enters 'q'
    while (1)
    {
        // option for printing shapes
        if (option == 1)
        {
            printf("Press 1 to draw oval\n");
            printf("Press 2 to draw hut\n");
            printf("Press 3 to draw line\n");
            printf("Press 4 to draw kite\n");
            printf("Press 5 to draw heart\n");
            printf("Press 6 to draw square\n");
            printf("Press 7 to draw numbers\n");
            printf("Press 8 to draw arrows\n");
            printf("Press 9 to draw chatbox\n");
            printf("Press 10 to draw diamond\n");
            printf("Press 11 to draw hexagon\n");
            printf("Press 12 to draw triangle\n");
            printf("Press 13 to draw pentagon\n");
            printf("Press 14 to draw alphabets\n");
            printf("Press 15 to draw rectangle\n");
            printf("Press 16 to draw trapezium\n");
            printf("Press 17 to draw parallelogram\n");
            scanf("%d", &shape);
            //////oval
            if (shape == 1)
            {
                void oval_interface();
                {
                    int size, fill_type, outline_color_choice, position;
                    char character;
                    printf("Enter the size: ");
                    scanf("%d", &size);

                    printf("Enter the symbol: ");
                    scanf(" %c", &character);

                    printf("Select the position of the output shape:\n");
                    printf("1.left\n2.middle\n3.right\n");
                    scanf("%d", &position);

                    printf("Enter the fill type (1 for fill and 0 for hollow): ");
                    scanf("%d", &fill_type);

                    printf("Enter the outline color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &outline_color_choice);
                    switch (outline_color_choice)
                    {
                    case 1:
                        outline_color_choice = 31; // Red
                        break;
                    case 2:
                        outline_color_choice = 32; // Green
                        break;
                    case 3:
                        outline_color_choice = 34; // Blue
                        break;
                    case 4:
                        outline_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        outline_color_choice = 0; // Default (White)
                    }
                    clear_screen();
                    oval_functions(fill_type, size, outline_color_choice, character, position);
                }
                printf("\nPress 0 or anyother key to go back to the main menu and q to end the program.\n");
                scanf(" %c", &key);
                if (key == 'q')
                {
                    printf("Your program has been ended.\n");
                    exit(0);
                }
                else
                {
                    printf("------------------------------------------------------------------------------------\n");
                    printf("|                                   Options                                        |\n");
                    printf("------------------------------------------------------------------------------------\n");
                    printf("Press 1 to make shapes\n");
                    printf("Press 2 to draw on terminal\n");
                    printf("Press 3 to save the file\n");
                    printf("Press 4 to view existing file\n");
                    printf("Press 5 to edit an existing file\n");
                    printf("Press q to quit\n");
                    scanf("%d", &option);
                    continue;
                }
            }
            //////hut
            else if (shape == 2)
            {
                void hut_interface();
                {
                    int size, outline_color_choice, fill_type, position;
                    char character;
                    printf("Enter the size: ");
                    scanf("%d", &size);

                    printf("Enter the symbol: ");
                    scanf(" %c", &character);

                    printf("Select the position of the output shape:\n");
                    printf("1.left\n2.middle\n3.right\n");
                    scanf("%d", &position);

                    printf("Enter the fill type (1 for fill): ");
                    scanf("%d", &fill_type);

                    printf("Enter the color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &outline_color_choice);
                    switch (outline_color_choice)
                    {
                    case 1:
                        outline_color_choice = 31; // Red
                        break;
                    case 2:
                        outline_color_choice = 32; // Green
                        break;
                    case 3:
                        outline_color_choice = 34; // Blue
                        break;
                    case 4:
                        outline_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        outline_color_choice = 0; // Default (White)
                    }
                    clear_screen();
                    hut_functions(fill_type, size, outline_color_choice, character, position);
                }
                printf("\nPress 0 or anyother key to go back to the main menu and q to end the program.\n");
                scanf(" %c", &key);
                if (key == 'q')
                {
                    printf("Your program has been ended.\n");
                    exit(0);
                }
                else
                {
                    printf("------------------------------------------------------------------------------------\n");
                    printf("|                                   Options                                        |\n");
                    printf("------------------------------------------------------------------------------------\n");
                    printf("Press 1 to make shapes\n");
                    printf("Press 2 to draw on terminal\n");
                    printf("Press 3 to save the file\n");
                    printf("Press 4 to view existing file\n");
                    printf("Press 5 to edit an existing file\n");
                    printf("Press q to quit\n");
                    scanf("%d", &option);
                    continue;
                }
            }
            //////line
            else if (shape == 3)
            {
                void line_interface();
                {
                    int size, outline_color_choice, shape_type, position;
                    char character;
                    printf("Enter the size: ");
                    scanf("%d", &size);

                    printf("Enter the symbol: ");
                    scanf(" %c", &character);

                    printf("Select the position of the output shape:\n");
                    printf("1.left\n2.middle\n3.right\n");
                    scanf("%d", &position);

                    printf("Enter the shape type (1 for horizontal and 0 for vertical): ");
                    scanf("%d", &shape_type);

                    printf("Enter the color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &outline_color_choice);
                    switch (outline_color_choice)
                    {
                    case 1:
                        outline_color_choice = 31; // Red
                        break;
                    case 2:
                        outline_color_choice = 32; // Green
                        break;
                    case 3:
                        outline_color_choice = 34; // Blue
                        break;
                    case 4:
                        outline_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        outline_color_choice = 0; // Default (White)
                    }
                    clear_screen();
                    line_functions(shape_type, size, outline_color_choice, character, position);
                }
                printf("\nPress 0 or anyother key to go back to the main menu and q to end the program.\n");
                scanf(" %c", &key);
                if (key == 'q')
                {
                    printf("Your program has been ended.\n");
                    exit(0);
                }
                else
                {
                    printf("------------------------------------------------------------------------------------\n");
                    printf("|                                   Options                                        |\n");
                    printf("------------------------------------------------------------------------------------\n");
                    printf("Press 1 to make shapes\n");
                    printf("Press 2 to draw on terminal\n");
                    printf("Press 3 to save the file\n");
                    printf("Press 4 to view existing file\n");
                    printf("Press 5 to edit an existing file\n");
                    printf("Press q to quit\n");
                    scanf("%d", &option);
                    continue;
                }
            }
            ///////kite
            else if (shape == 4)
            {
                void kite_interface();
                {
                    int size, outline_color_choice, fill_type, fill_color_choice, position;
                    char character;
                    printf("Enter the size: ");
                    scanf("%d", &size);

                    printf("Enter the symbol: ");
                    scanf(" %c", &character);

                    printf("Select the position of the output shape:\n");
                    printf("1.left\n2.middle\n3.right\n");
                    scanf("%d", &position);

                    printf("Enter the fill type (1 for fill and 0 for hollow): ");
                    scanf("%d", &fill_type);

                    printf("Enter the outline color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &outline_color_choice);
                    switch (outline_color_choice)
                    {
                    case 1:
                        outline_color_choice = 31; // Red
                        break;
                    case 2:
                        outline_color_choice = 32; // Green
                        break;
                    case 3:
                        outline_color_choice = 34; // Blue
                        break;
                    case 4:
                        outline_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        outline_color_choice = 0; // Default (White)
                    }
                    printf("Enter the fill color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &fill_color_choice);
                    switch (fill_color_choice)
                    {
                    case 1:
                        fill_color_choice = 31; // Red
                        break;
                    case 2:
                        fill_color_choice = 32; // Green
                        break;
                    case 3:
                        fill_color_choice = 34; // Blue
                        break;
                    case 4:
                        fill_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        fill_color_choice = 0; // Default (White)
                    }
                    clear_screen();
                    kite_functions(fill_type, size, outline_color_choice, fill_color_choice, character, position);
                }
                printf("\nPress 0 or anyother key to go back to the main menu and q to end the program.\n");
                scanf(" %c", &key);
                if (key == 'q')
                {
                    printf("Your program has been ended.\n");
                    exit(0);
                }
                else
                {
                    printf("------------------------------------------------------------------------------------\n");
                    printf("|                                   Options                                        |\n");
                    printf("------------------------------------------------------------------------------------\n");
                    printf("Press 1 to make shapes\n");
                    printf("Press 2 to draw on terminal\n");
                    printf("Press 3 to save the file\n");
                    printf("Press 4 to view existing file\n");
                    printf("Press 5 to edit an existing file\n");
                    printf("Press q to quit\n");
                    scanf("%d", &option);
                    continue;
                }
            }
            //////heart
            else if (shape == 5)
            {
                void heart_interface();
                {
                    int size, outline_color_choice, fill_type, fill_color_choice, position;
                    char character;
                    printf("Enter the size: ");
                    scanf("%d", &size);

                    printf("Enter the symbol: ");
                    scanf(" %c", &character);

                    printf("Select the position of the output shape:\n");
                    printf("1.left\n2.middle\n3.right\n");
                    scanf("%d", &position);

                    printf("Enter the fill type (1 for fill and 0 for hollow): ");
                    scanf("%d", &fill_type);

                    printf("Enter the outline color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &outline_color_choice);
                    switch (outline_color_choice)
                    {
                    case 1:
                        outline_color_choice = 31; // Red
                        break;
                    case 2:
                        outline_color_choice = 32; // Green
                        break;
                    case 3:
                        outline_color_choice = 34; // Blue
                        break;
                    case 4:
                        outline_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        outline_color_choice = 0; // Default (White)
                    }

                    printf("Enter the fill color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &fill_color_choice);
                    switch (fill_color_choice)
                    {
                    case 1:
                        fill_color_choice = 31; // Red
                        break;
                    case 2:
                        fill_color_choice = 32; // Green
                        break;
                    case 3:
                        fill_color_choice = 34; // Blue
                        break;
                    case 4:
                        fill_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        fill_color_choice = 0; // Default (White)
                    }
                    clear_screen();
                    heart_functions(fill_type, size, outline_color_choice, fill_color_choice, character, position);
                }
                printf("\nPress 0 or anyother key to go back to the main menu and q to end the program.\n");
                scanf(" %c", &key);
                if (key == 'q')
                {
                    printf("Your program has been ended.\n");
                    exit(0);
                }
                else
                {
                    printf("------------------------------------------------------------------------------------\n");
                    printf("|                                   Options                                        |\n");
                    printf("------------------------------------------------------------------------------------\n");
                    printf("Press 1 to make shapes\n");
                    printf("Press 2 to draw on terminal\n");
                    printf("Press 3 to save the file\n");
                    printf("Press 4 to view existing file\n");
                    printf("Press 5 to edit an existing file\n");
                    printf("Press q to quit\n");
                    scanf("%d", &option);
                    continue;
                }
            }
            //////square
            else if (shape == 6)
            {
                void square_interfqace();
                {
                    int size, outline_color_choice, fill_type, fill_color_choice, position;
                    char character;
                    printf("Enter the size: ");
                    scanf("%d", &size);

                    printf("Enter the symbol: ");
                    scanf(" %c", &character);

                    printf("Select the position of the output shape:\n");
                    printf("1.left\n2.middle\n3.right\n");
                    scanf("%d", &position);

                    printf("Enter the fill type (1 for fill and 0 for hollow): ");
                    scanf("%d", &fill_type);

                    printf("Enter the outline color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &outline_color_choice);
                    switch (outline_color_choice)
                    {
                    case 1:
                        outline_color_choice = 31; // Red
                        break;
                    case 2:
                        outline_color_choice = 32; // Green
                        break;
                    case 3:
                        outline_color_choice = 34; // Blue
                        break;
                    case 4:
                        outline_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        outline_color_choice = 0; // Default (White)
                    }

                    printf("Enter the fill color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &fill_color_choice);
                    switch (fill_color_choice)
                    {
                    case 1:
                        fill_color_choice = 31; // Red
                        break;
                    case 2:
                        fill_color_choice = 32; // Green
                        break;
                    case 3:
                        fill_color_choice = 34; // Blue
                        break;
                    case 4:
                        fill_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        fill_color_choice = 0; // Default (White)
                    }
                    clear_screen();
                    square_functions(fill_type, size, outline_color_choice, fill_color_choice, character, position);
                }
                printf("\nPress 0 or anyother key to go back to the main menu and q to end the program.\n");
                scanf(" %c", &key);
                if (key == 'q')
                {
                    printf("Your program has been ended.\n");
                    exit(0);
                }
                else
                {
                    printf("------------------------------------------------------------------------------------\n");
                    printf("|                                   Options                                        |\n");
                    printf("------------------------------------------------------------------------------------\n");
                    printf("Press 1 to make shapes\n");
                    printf("Press 2 to draw on terminal\n");
                    printf("Press 3 to save the file\n");
                    printf("Press 4 to view existing file\n");
                    printf("Press 5 to edit an existing file\n");
                    printf("Press q to quit\n");
                    scanf("%d", &option);
                    continue;
                }
            }
            /////numbers
            else if (shape == 7)
            {
                void numbers_interface();
                {
                    int size, start, end, outline_color_choice, position;
                    char character;
                    printf("Enter the size: ");
                    scanf("%d", &size);

                    printf("Enter the symbol: ");
                    scanf(" %c", &character);

                    printf("Select the position of the output shape:\n");
                    printf("1.left\n2.middle\n3.right\n");
                    scanf("%d", &position);

                    printf("Enter the starting number: ");
                    scanf(" %d", &start);

                    printf("Enter the ending number: ");
                    scanf(" %d", &end);

                    printf("Enter the color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &outline_color_choice);
                    switch (outline_color_choice)
                    {
                    case 1:
                        outline_color_choice = 31; // Red
                        break;
                    case 2:
                        outline_color_choice = 32; // Green
                        break;
                    case 3:
                        outline_color_choice = 34; // Blue
                        break;
                    case 4:
                        outline_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        outline_color_choice = 0; // Default (White)
                    }
                    for (int num = start; num <= end; num++)
                    {
                        numbers_functions(num, size, outline_color_choice, character, position);
                    }
                }
                printf("\nPress 0 or anyother key to go back to the main menu and q to end the program.\n");
                scanf(" %c", &key);
                if (key == 'q')
                {
                    printf("Your program has been ended.\n");
                    exit(0);
                }
                else
                {
                    printf("------------------------------------------------------------------------------------\n");
                    printf("|                                   Options                                        |\n");
                    printf("------------------------------------------------------------------------------------\n");
                    printf("Press 1 to make shapes\n");
                    printf("Press 2 to draw on terminal\n");
                    printf("Press 3 to save the file\n");
                    printf("Press 4 to view existing file\n");
                    printf("Press 5 to edit an existing file\n");
                    printf("Press q to quit\n");
                    scanf("%d", &option);
                    continue;
                }
            }
            ///////arrows
            else if (shape == 8)
            {
                void arrows_interface();
                {
                    int size, outline_color_choice, fill_type, shape_type, fill_color_choice, position;
                    char character;
                    printf("Enter the size: ");
                    scanf("%d", &size);

                    printf("Enter the symbol: ");
                    scanf(" %c", &character);

                    printf("Select the position of the output shape:\n");
                    printf("1.left\n2.middle\n3.right\n");
                    scanf("%d", &position);

                    printf("Enter the fill type (1 for fill and 0 for hollow): ");
                    scanf("%d", &fill_type);

                    printf("Enter the shape type (1 for up, 2 for down, 3 for left and 4 for right): ");
                    scanf("%d", &shape_type);

                    printf("Enter the outline color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &outline_color_choice);
                    switch (outline_color_choice)
                    {
                    case 1:
                        outline_color_choice = 31; // Red
                        break;
                    case 2:
                        outline_color_choice = 32; // Green
                        break;
                    case 3:
                        outline_color_choice = 34; // Blue
                        break;
                    case 4:
                        outline_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        outline_color_choice = 0; // Default (White)
                    }

                    printf("Enter the fill color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &fill_color_choice);
                    switch (fill_color_choice)
                    {
                    case 1:
                        fill_color_choice = 31; // Red
                        break;
                    case 2:
                        fill_color_choice = 32; // Green
                        break;
                    case 3:
                        fill_color_choice = 34; // Blue
                        break;
                    case 4:
                        fill_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        fill_color_choice = 0; // Default (White)
                    }
                    clear_screen();
                    arrows_functions(shape_type, fill_type, size, outline_color_choice, fill_color_choice, character, position);
                }
                printf("\nPress 0 or anyother key to go back to the main menu and q to end the program.\n");
                scanf(" %c", &key);
                if (key == 'q')
                {
                    printf("Your program has been ended.\n");
                    exit(0);
                }
                else
                {
                    printf("------------------------------------------------------------------------------------\n");
                    printf("|                                   Options                                        |\n");
                    printf("------------------------------------------------------------------------------------\n");
                    printf("Press 1 to make shapes\n");
                    printf("Press 2 to draw on terminal\n");
                    printf("Press 3 to save the file\n");
                    printf("Press 4 to view existing file\n");
                    printf("Press 5 to edit an existing file\n");
                    printf("Press q to quit\n");
                    scanf("%d", &option);
                    continue;
                }
            }
            //////chatbox
            else if (shape == 9)
            {
                void chatbox_interface();
                {
                    int size, outline_color_choice, fill_color_choice, fill_type, position;
                    char character;
                    printf("Enter the size: ");
                    scanf("%d", &size);

                    printf("Enter the symbol: ");
                    scanf(" %c", &character);

                    printf("Select the position of the output shape:\n");
                    printf("1.left\n2.middle\n3.right\n");
                    scanf("%d", &position);

                    printf("Enter the fill type (1 for fill and 0 for hollow): ");
                    scanf("%d", &fill_type);

                    printf("Enter the outline color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &outline_color_choice);
                    switch (outline_color_choice)
                    {
                    case 1:
                        outline_color_choice = 31; // Red
                        break;
                    case 2:
                        outline_color_choice = 32; // Green
                        break;
                    case 3:
                        outline_color_choice = 34; // Blue
                        break;
                    case 4:
                        outline_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        outline_color_choice = 0; // Default (White)
                    }

                    printf("Enter the fill color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &fill_color_choice);
                    switch (fill_color_choice)
                    {
                    case 1:
                        fill_color_choice = 31; // Red
                        break;
                    case 2:
                        fill_color_choice = 32; // Green
                        break;
                    case 3:
                        fill_color_choice = 34; // Blue
                        break;
                    case 4:
                        fill_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        fill_color_choice = 0; // Default (White)
                    }
                    clear_screen();
                    chatbox_functions(fill_type, size, outline_color_choice, fill_color_choice, character, position);
                }
                printf("\nPress 0 or anyother key to go back to the main menu and q to end the program.\n");
                scanf(" %c", &key);
                if (key == 'q')
                {
                    printf("Your program has been ended.\n");
                    exit(0);
                }
                else
                {
                    printf("------------------------------------------------------------------------------------\n");
                    printf("|                                   Options                                        |\n");
                    printf("------------------------------------------------------------------------------------\n");
                    printf("Press 1 to make shapes\n");
                    printf("Press 2 to draw on terminal\n");
                    printf("Press 3 to save the file\n");
                    printf("Press 4 to view existing file\n");
                    printf("Press 5 to edit an existing file\n");
                    printf("Press q to quit\n");
                    scanf("%d", &option);
                    continue;
                }
            }
            //////diamond
            else if (shape == 10)
            {
                void diamond_interface();
                {
                    int size, outline_color_choice, fill_color_choice, fill_type, shape_type, position;
                    char character;
                    printf("Enter the size: ");
                    scanf("%d", &size);

                    printf("Enter the symbol: ");
                    scanf(" %c", &character);

                    printf("Select the position of the output shape:\n");
                    printf("1.left\n2.middle\n3.right\n");
                    scanf("%d", &position);

                    printf("Enter the fill type (1 for fill and 0 for hollow): ");
                    scanf("%d", &fill_type);

                    printf("Enter the shape type (1 for simple and 0 for half): ");
                    scanf("%d", &shape_type);

                    printf("Enter the outline color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &outline_color_choice);
                    switch (outline_color_choice)
                    {
                    case 1:
                        outline_color_choice = 31; // Red
                        break;
                    case 2:
                        outline_color_choice = 32; // Green
                        break;
                    case 3:
                        outline_color_choice = 34; // Blue
                        break;
                    case 4:
                        outline_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        outline_color_choice = 0; // Default (White)
                    }

                    printf("Enter the fill color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &fill_color_choice);
                    switch (fill_color_choice)
                    {
                    case 1:
                        fill_color_choice = 31; // Red
                        break;
                    case 2:
                        fill_color_choice = 32; // Green
                        break;
                    case 3:
                        fill_color_choice = 34; // Blue
                        break;
                    case 4:
                        fill_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        fill_color_choice = 0; // Default (White)
                    }
                    clear_screen();
                    diamond_functions(shape_type, fill_type, size, outline_color_choice, fill_color_choice, character, position);
                }
                printf("\nPress 0 or anyother key to go back to the main menu and q to end the program.\n");
                scanf(" %c", &key);
                if (key == 'q')
                {
                    printf("Your program has been ended.\n");
                    exit(0);
                }
                else
                {
                    printf("------------------------------------------------------------------------------------\n");
                    printf("|                                   Options                                        |\n");
                    printf("------------------------------------------------------------------------------------\n");
                    printf("Press 1 to make shapes\n");
                    printf("Press 2 to draw on terminal\n");
                    printf("Press 3 to save the file\n");
                    printf("Press 4 to view existing file\n");
                    printf("Press 5 to edit an existing file\n");
                    printf("Press q to quit\n");
                    scanf("%d", &option);
                    continue;
                }
            }
            ///////hexagon
            else if (shape == 11)
            {
                void hexagon_interface();
                {
                    int size, outline_color_choice, fill_type, fill_color_choice, position;
                    char character;
                    printf("Enter the size: ");
                    scanf("%d", &size);

                    printf("Enter the symbol: ");
                    scanf(" %c", &character);

                    printf("Select the position of the output shape:\n");
                    printf("1.left\n2.middle\n3.right\n");
                    scanf("%d", &position);

                    printf("Enter the fill type (1 for fill and 0 for hollow): ");
                    scanf("%d", &fill_type);

                    printf("Enter the outline color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &outline_color_choice);
                    switch (outline_color_choice)
                    {
                    case 1:
                        outline_color_choice = 31; // Red
                        break;
                    case 2:
                        outline_color_choice = 32; // Green
                        break;
                    case 3:
                        outline_color_choice = 34; // Blue
                        break;
                    case 4:
                        outline_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        outline_color_choice = 0; // Default (White)
                    }

                    printf("Enter the fill color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &fill_color_choice);
                    switch (fill_color_choice)
                    {
                    case 1:
                        fill_color_choice = 31; // Red
                        break;
                    case 2:
                        fill_color_choice = 32; // Green
                        break;
                    case 3:
                        fill_color_choice = 34; // Blue
                        break;
                    case 4:
                        fill_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        fill_color_choice = 0; // Default (White)
                    }
                    clear_screen();
                    hexagon_functions(fill_type, size, outline_color_choice, fill_color_choice, character, position);
                }
                printf("\nPress 0 or anyother key to go back to the main menu and q to end the program.\n");
                scanf(" %c", &key);
                if (key == 'q')
                {
                    printf("Your program has been ended.\n");
                    exit(0);
                }
                else
                {
                    printf("------------------------------------------------------------------------------------\n");
                    printf("|                                   Options                                        |\n");
                    printf("------------------------------------------------------------------------------------\n");
                    printf("Press 1 to make shapes\n");
                    printf("Press 2 to draw on terminal\n");
                    printf("Press 3 to save the file\n");
                    printf("Press 4 to view existing file\n");
                    printf("Press 5 to edit an existing file\n");
                    printf("Press q to quit\n");
                    scanf("%d", &option);
                    continue;
                }
            }
            ///////triangle
            else if (shape == 12)
            {
                void triangle_interface();
                {
                    int size, outline_color_choice, fill_type, shape_type, fill_color_choice, position;
                    char character;
                    printf("Enter the size: ");
                    scanf("%d", &size);

                    printf("Enter the symbol: ");
                    scanf(" %c", &character);

                    printf("Select the position of the output shape:\n");
                    printf("1.left\n2.middle\n3.right\n");
                    scanf("%d", &position);

                    printf("Enter the fill type (1 for fill and 0 for hollow): ");
                    scanf("%d", &fill_type);

                    printf("Enter the shape type (1 for simple and 0 for inverted): ");
                    scanf("%d", &shape_type);

                    printf("Enter the outline color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &outline_color_choice);
                    switch (outline_color_choice)
                    {
                    case 1:
                        outline_color_choice = 31; // Red
                        break;
                    case 2:
                        outline_color_choice = 32; // Green
                        break;
                    case 3:
                        outline_color_choice = 34; // Blue
                        break;
                    case 4:
                        outline_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        outline_color_choice = 0; // Default (White)
                    }

                    printf("Enter the fill color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &fill_color_choice);
                    switch (fill_color_choice)
                    {
                    case 1:
                        fill_color_choice = 31; // Red
                        break;
                    case 2:
                        fill_color_choice = 32; // Green
                        break;
                    case 3:
                        fill_color_choice = 34; // Blue
                        break;
                    case 4:
                        fill_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        fill_color_choice = 0; // Default (White)
                    }
                    clear_screen();
                    triangle_functions(shape_type, fill_type, size, outline_color_choice, fill_color_choice, character, position);
                }
                printf("\nPress 0 or anyother key to go back to the main menu and q to end the program.\n");
                scanf(" %c", &key);
                if (key == 'q')
                {
                    printf("Your program has been ended.\n");
                    exit(0);
                }
                else
                {
                    printf("------------------------------------------------------------------------------------\n");
                    printf("|                                   Options                                        |\n");
                    printf("------------------------------------------------------------------------------------\n");
                    printf("Press 1 to make shapes\n");
                    printf("Press 2 to draw on terminal\n");
                    printf("Press 3 to save the file\n");
                    printf("Press 4 to view existing file\n");
                    printf("Press 5 to edit an existing file\n");
                    printf("Press q to quit\n");
                    scanf("%d", &option);
                    continue;
                }
            }
            //////pentagon
            else if (shape == 13)
            {
                void pentagon_interface();
                {
                    int size, outline_color_choice, fill_color_choice, fill_type, shape_type, position;
                    char character;
                    printf("Enter the size: ");
                    scanf("%d", &size);

                    printf("Enter the symbol: ");
                    scanf(" %c", &character);

                    printf("Select the position of the output shape:\n");
                    printf("1.left\n2.middle\n3.right\n");
                    scanf("%d", &position);

                    printf("Enter the fill type (1 for fill and 0 for hollow): ");
                    scanf("%d", &fill_type);

                    printf("Enter the shape type (1 for simple and 0 for inverted): ");
                    scanf("%d", &shape_type);

                    printf("Enter the outline color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &outline_color_choice);
                    switch (outline_color_choice)
                    {
                    case 1:
                        outline_color_choice = 31; // Red
                        break;
                    case 2:
                        outline_color_choice = 32; // Green
                        break;
                    case 3:
                        outline_color_choice = 34; // Blue
                        break;
                    case 4:
                        outline_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        outline_color_choice = 0; // Default (White)
                    }

                    printf("Enter the fill color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &fill_color_choice);
                    switch (fill_color_choice)
                    {
                    case 1:
                        fill_color_choice = 31; // Red
                        break;
                    case 2:
                        fill_color_choice = 32; // Green
                        break;
                    case 3:
                        fill_color_choice = 34; // Blue
                        break;
                    case 4:
                        fill_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        fill_color_choice = 0; // Default (White)
                    }
                    clear_screen();
                    pentagon_functions(shape_type, fill_type, size, outline_color_choice, fill_color_choice, character, position);
                }
                printf("\nPress 0 or anyother key to go back to the main menu and q to end the program.\n");
                scanf(" %c", &key);
                if (key == 'q')
                {
                    printf("Your program has been ended.\n");
                    exit(0);
                }
                else
                {
                    printf("------------------------------------------------------------------------------------\n");
                    printf("|                                   Options                                        |\n");
                    printf("------------------------------------------------------------------------------------\n");
                    printf("Press 1 to make shapes\n");
                    printf("Press 2 to draw on terminal\n");
                    printf("Press 3 to save the file\n");
                    printf("Press 4 to view existing file\n");
                    printf("Press 5 to edit an existing file\n");
                    printf("Press q to quit\n");
                    scanf("%d", &option);
                    continue;
                }
            }
            ///////alphabets
            else if (shape == 14)
            {
                void alphabets_interface();
                {
                    int size, outline_color_choice, position;
                    char character, start, end;
                    printf("Enter the size: ");
                    scanf("%d", &size);

                    printf("Enter the symbol: ");
                    scanf(" %c", &character);

                    printf("Select the position of the output shape:\n");
                    printf("1.left\n2.middle\n3.right\n");
                    scanf("%d", &position);

                    printf("Enter the starting alphabet: \n");
                    scanf(" %c", &start);

                    printf("Enter the ending alphabet: \n");
                    scanf(" %c", &end);

                    printf("Enter the outline color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &outline_color_choice);
                    switch (outline_color_choice)
                    {
                    case 1:
                        outline_color_choice = 31; // Red
                        break;
                    case 2:
                        outline_color_choice = 32; // Green
                        break;
                    case 3:
                        outline_color_choice = 34; // Blue
                        break;
                    case 4:
                        outline_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        outline_color_choice = 0; // Default (White)
                    }
                    for (char alpha = start; alpha <= end; alpha++)
                    {
                        alphabets_functions(alpha, size, outline_color_choice, character, position);
                    }
                }
                printf("\nPress 0 or anyother key to go back to the main menu and q to end the program.\n");
                scanf(" %c", &key);
                if (key == 'q')
                {
                    printf("Your program has been ended.\n");
                    exit(0);
                }
                else
                {
                    printf("------------------------------------------------------------------------------------\n");
                    printf("|                                   Options                                        |\n");
                    printf("------------------------------------------------------------------------------------\n");
                    printf("Press 1 to make shapes\n");
                    printf("Press 2 to draw on terminal\n");
                    printf("Press 3 to save the file\n");
                    printf("Press 4 to view existing file\n");
                    printf("Press 5 to edit an existing file\n");
                    printf("Press q to quit\n");
                    scanf("%d", &option);
                    continue;
                }
            }
            ///////recatngle
            else if (shape == 15)
            {
                void rectangle_interface();
                {
                    int size, outline_color_choice, fill_type, fill_color_choice, position;
                    char character;
                    printf("Enter the size: ");
                    scanf("%d", &size);

                    printf("Enter the symbol: ");
                    scanf(" %c", &character);

                    printf("Select the position of the output shape:\n");
                    printf("1.left\n2.middle\n3.right\n");
                    scanf("%d", &position);

                    printf("Enter the fill type (1 for fill and 0 for hollow): ");
                    scanf("%d", &fill_type);

                    printf("Enter the outline color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &outline_color_choice);
                    switch (outline_color_choice)
                    {
                    case 1:
                        outline_color_choice = 31; // Red
                        break;
                    case 2:
                        outline_color_choice = 32; // Green
                        break;
                    case 3:
                        outline_color_choice = 34; // Blue
                        break;
                    case 4:
                        outline_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        outline_color_choice = 0; // Default (White)
                    }

                    printf("Enter the fill color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &fill_color_choice);
                    switch (fill_color_choice)
                    {
                    case 1:
                        fill_color_choice = 31; // Red
                        break;
                    case 2:
                        fill_color_choice = 32; // Green
                        break;
                    case 3:
                        fill_color_choice = 34; // Blue
                        break;
                    case 4:
                        fill_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        fill_color_choice = 0; // Default (White)
                    }
                    clear_screen();
                    rectangle_functions(fill_type, size, outline_color_choice, fill_color_choice, character, position);
                }
                printf("\nPress 0 or anyother key to go back to the main menu and q to end the program.\n");
                scanf(" %c", &key);
                if (key == 'q')
                {
                    printf("Your program has been ended.\n");
                    exit(0);
                }
                else
                {
                    printf("------------------------------------------------------------------------------------\n");
                    printf("|                                   Options                                        |\n");
                    printf("------------------------------------------------------------------------------------\n");
                    printf("Press 1 to make shapes\n");
                    printf("Press 2 to draw on terminal\n");
                    printf("Press 3 to save the file\n");
                    printf("Press 4 to view existing file\n");
                    printf("Press 5 to edit an existing file\n");
                    printf("Press q to quit\n");
                    scanf("%d", &option);
                    continue;
                }
            }
            ///////trapezium
            else if (shape == 16)
            {
                void trapezium_interface();
                {
                    int size, outline_color_choice, fill_color_choice, fill_type, shape_type, position;
                    char character;
                    printf("Enter the size: ");
                    scanf("%d", &size);

                    printf("Enter the symbol: ");
                    scanf(" %c", &character);

                    printf("Select the position of the output shape:\n");
                    printf("1.left\n2.middle\n3.right\n");
                    scanf("%d", &position);

                    printf("Enter the fill type (1 for fill and 0 for hollow): ");
                    scanf("%d", &fill_type);

                    printf("Enter the shape type (1 for simple and 0 for inverted): ");
                    scanf("%d", &shape_type);

                    printf("Enter the outline color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &outline_color_choice);
                    switch (outline_color_choice)
                    {
                    case 1:
                        outline_color_choice = 31; // Red
                        break;
                    case 2:
                        outline_color_choice = 32; // Green
                        break;
                    case 3:
                        outline_color_choice = 34; // Blue
                        break;
                    case 4:
                        outline_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        outline_color_choice = 0; // Default (White)
                    }

                    printf("Enter the fill color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &fill_color_choice);
                    switch (fill_color_choice)
                    {
                    case 1:
                        fill_color_choice = 31; // Red
                        break;
                    case 2:
                        fill_color_choice = 32; // Green
                        break;
                    case 3:
                        fill_color_choice = 34; // Blue
                        break;
                    case 4:
                        fill_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        fill_color_choice = 0; // Default (White)
                    }
                    clear_screen();
                    trapezium_functions(shape_type, fill_type, size, outline_color_choice, fill_color_choice, character, position);
                }
                printf("\nPress 0 or anyother key to go back to the main menu and q to end the program.\n");
                scanf(" %c", &key);
                if (key == 'q')
                {
                    printf("Your program has been ended.\n");
                    exit(0);
                }
                else
                {
                    printf("------------------------------------------------------------------------------------\n");
                    printf("|                                   Options                                        |\n");
                    printf("------------------------------------------------------------------------------------\n");
                    printf("Press 1 to make shapes\n");
                    printf("Press 2 to draw on terminal\n");
                    printf("Press 3 to save the file\n");
                    printf("Press 4 to view existing file\n");
                    printf("Press 5 to edit an existing file\n");
                    printf("Press q to quit\n");
                    scanf("%d", &option);
                    continue;
                }
            }
            ///////parallelogram
            else if (shape == 17)
            {
                void parallelogram_interface();
                {
                    int size, outline_color_choice, fill_type, fill_color_choice, position;
                    char character;
                    printf("Enter the size: ");
                    scanf("%d", &size);

                    printf("Enter the symbol: ");
                    scanf(" %c", &character);

                    printf("Select the position of the output shape:\n");
                    printf("1.left\n2.middle\n3.right\n");
                    scanf("%d", &position);

                    printf("Enter the fill type (1 for fill and 0 for hollow): ");
                    scanf("%d", &fill_type);

                    printf("Enter the outline color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &outline_color_choice);
                    switch (outline_color_choice)
                    {
                    case 1:
                        outline_color_choice = 31; // Red
                        break;
                    case 2:
                        outline_color_choice = 32; // Green
                        break;
                    case 3:
                        outline_color_choice = 34; // Blue
                        break;
                    case 4:
                        outline_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        outline_color_choice = 0; // Default (White)
                    }

                    printf("Enter the fill color: \n");
                    printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                    scanf("%d", &fill_color_choice);
                    switch (fill_color_choice)
                    {
                    case 1:
                        fill_color_choice = 31; // Red
                        break;
                    case 2:
                        fill_color_choice = 32; // Green
                        break;
                    case 3:
                        fill_color_choice = 34; // Blue
                        break;
                    case 4:
                        fill_color_choice = 33; // Yellow
                        break;
                    case 5:
                    default:
                        fill_color_choice = 0; // Default (White)
                    }
                    clear_screen();
                    parallelogram_functions(fill_type, size, outline_color_choice, fill_color_choice, character, position);
                }
                printf("\nPress 0 or anyother key to go back to the main menu and q to end the program.\n");
                scanf(" %c", &key);
                if (key == 'q')
                {
                    printf("Your program has been ended.\n");
                    exit(0);
                }
                else
                {
                    printf("------------------------------------------------------------------------------------\n");
                    printf("|                                   Options                                        |\n");
                    printf("------------------------------------------------------------------------------------\n");
                    printf("Press 1 to make shapes\n");
                    printf("Press 2 to draw on terminal\n");
                    printf("Press 3 to save the file\n");
                    printf("Press 4 to view existing file\n");
                    printf("Press 5 to edit an existing file\n");
                    printf("Press q to quit\n");
                    scanf("%d", &option);
                    continue;
                }
            }
        }

        // option for freehand drawing
        if (option == 2)
        {
            void freehand_drawing_interface();
            {
                char character;
                printf("Enter the symbol: ");
                scanf(" %c", &character);

                int outline_color_choice;
                printf("Enter the outline color: \n");
                printf("1.Red\n2.Green\n3.Blue\n4.Yellow\n5.Default(White)\n");
                scanf("%d", &outline_color_choice);
                switch (outline_color_choice)
                {
                case 1:
                    outline_color_choice = 31; // Red
                    break;
                case 2:
                    outline_color_choice = 32; // Green
                    break;
                case 3:
                    outline_color_choice = 34; // Blue
                    break;
                case 4:
                    outline_color_choice = 33; // Yellow
                    break;
                case 5:
                default:
                    outline_color_choice = 0; // Default (White)
                }
                freehand_drawing_functions(outline_color_choice, character);
            }
            printf("\nPress 0 or anyother key to go back to the main menu and q to end the program.\n");
            scanf(" %c", &key);
            if (key == 'q')
            {
                printf("Your program has been ended.\n");
                exit(0);
            }
            else
            {
                printf("------------------------------------------------------------------------------------\n");
                printf("|                                   Options                                        |\n");
                printf("------------------------------------------------------------------------------------\n");
                printf("Press 1 to make shapes\n");
                printf("Press 2 to draw on terminal\n");
                printf("Press 3 to save the file\n");
                printf("Press 4 to view existing file\n");
                printf("Press 5 to edit an existing file\n");
                printf("Press q to quit\n");
                scanf("%d", &option);
                continue;
            }
        }

        ////////// option to save file
        if (option == 3)
        {
            char file_name[500], folder_path[500];
            printf("Enter the folder path in which you want to save your file:\n");
            scanf("%499s", folder_path);
            printf("\nEnter the name of .txt file to save your shape:\n");
            scanf("%499s", file_name);
            char file_path[500];
            snprintf(file_path, sizeof(file_path), "%s%s", folder_path, file_name);
            FILE *fp = fopen("C:\\Users\\aresh\\Desktop\\PF_project\\save\\temp.txt", "r");
            if (fp == NULL)
            {
                printf("Error! This file does not exist.");
                break;
            }
            char buffer[5000];
            FILE *save = fopen(file_path, "w");
            if (save == NULL)
            {
                printf("Error! This file does not exist.");
                break;
            }
            while (fgets(buffer, 1000, fp))
            {
                fprintf(save, "%s", buffer);
            }
            fclose(save);
            printf("\nYour file has been saved.\n");
            printf("\nPress 0 or anyother key to go back to the main menu and q to end the program.\n");
            scanf(" %c", &key);
            if (key == 'q')
            {
                printf("Your program has been ended.\n");
                exit(0);
            }
            else
            {
                printf("------------------------------------------------------------------------------------\n");
                printf("|                                   Options                                        |\n");
                printf("------------------------------------------------------------------------------------\n");
                printf("Press 1 to make shapes\n");
                printf("Press 2 to draw on terminal\n");
                printf("Press 3 to save the file\n");
                printf("Press 4 to view existing file\n");
                printf("Press 5 to edit an existing file\n");
                printf("Press q to quit\n");
                scanf("%d", &option);
                continue;
            }
        }
        ////////// option to view existing file
        if (option == 4)
        {
            char file_name[500], folder_path[500];
            printf("\nEnter the folder path in which you want to open your file:\n");
            scanf("%499s", folder_path);
            printf("\nEnter the name of .txt file:\n");
            scanf("%499s", file_name);
            char file_path[500];
            snprintf(file_path, sizeof(file_path), "%s%s", folder_path, file_name);
            FILE *open = fopen(file_path, "r");
            if (open == NULL)
            {
                printf("Error! This file does not exist.");
            }

            char buffer[5000];
            while (fgets(buffer, 5000, open))
            {
                printf("%s", buffer);
            }
            fclose(open);

            printf("\nPress 0 or anyother key to go back to the main menu and q to end the program.\n");
            scanf(" %c", &key);
            if (key == 'q')
            {
                printf("Your program has been ended.\n");
                exit(0);
            }
            else
            {
                printf("------------------------------------------------------------------------------------\n");
                printf("|                                   Options                                        |\n");
                printf("------------------------------------------------------------------------------------\n");
                printf("Press 1 to make shapes\n");
                printf("Press 2 to draw on terminal\n");
                printf("Press 3 to save the file\n");
                printf("Press 4 to view existing file\n");
                printf("Press 5 to edit an existing file\n");
                printf("Press q to quit\n");
                scanf("%d", &option);
                continue;
            }
        }

        ////////// option to edit an existing file
        if (option == 5)
        {
            printf("\nPress 1 if you want to append the data and press 2 if you want to replace the existing data.\n");
            scanf("%d", &option);
            // if the user wants to add at the end of the file
            if (option == 1)
            {
                char file_name[500], folder_path[500];
                printf("\nEnter the folder path in which you want to open your file:\n");
                scanf("%499s", folder_path);
                printf("\nEnter the name of .txt file:\n");
                scanf("%499s", file_name);
                char file_path[500];
                snprintf(file_path, sizeof(file_path), "%s%s", folder_path, file_name);

                if (!file_available(file_path))
                {
                    printf("Error! File does not exist.\n");
                }
                else
                {
                    FILE *edit = fopen(file_path, "a");
                    if (edit == NULL)
                    {
                        printf("Enter a valid file name.\n");
                    }
                    printf("\nEnter your data which you want to append:\n");
                    char buffer[5000];
                    scanf("%s", buffer);
                    fprintf(edit, "%s", buffer);
                    fclose(edit);
                    printf("\nYour data has been added to the file.\n");
                }
            }
            // if the user wants to replace the existing data
            else if (option == 2)
            {
                char file_name[500], file_path[500], folder_path[500];
                printf("\nEnter the folder path in which you want to open your file:\n");
                scanf("%499s", folder_path);
                printf("\nEnter the name of .txt file which you want to edit:\n");
                scanf("%499s", file_name);
                snprintf(file_path, sizeof(file_path), "%s%s", folder_path, file_name);

                if (!file_available(file_path))
                {
                    printf("Error! File does not exist.\n");
                }
                else
                {
                    FILE *write = fopen(file_path, "w");
                    if (write == NULL)
                    {
                        printf("Enter a valid file name.\n");
                    }
                    printf("\nEnter the data you want to write in your file:\n");
                    char buffer[5000];
                    scanf("%s", buffer);
                    fprintf(write, "%s", buffer);
                    fclose(write);
                    printf("\nYour data has been wriiten in the file.\n");
                }
            }
            printf("\nPress 0 or anyother key to go back to the main menu and q to end the program.\n");
            scanf(" %c", &key);
            if (key == 'q')
            {
                printf("Your program has been ended.\n");
                exit(0);
            }
            else
            {
                printf("------------------------------------------------------------------------------------\n");
                printf("|                                   Options                                        |\n");
                printf("------------------------------------------------------------------------------------\n");
                printf("Press 1 to make shapes\n");
                printf("Press 2 to draw on terminal\n");
                printf("Press 3 to save the file\n");
                printf("Press 4 to view existing file\n");
                printf("Press 5 to edit an existing file\n");
                printf("Press q to quit\n");
                scanf("%d", &option);
                continue;
            }
        }
        // if the user selects an option other than 1 to 5
        else
        {
            printf("Choose a valid option:\n");
            printf("------------------------------------------------------------------------------------\n");
            printf("|                                   Options                                        |\n");
            printf("------------------------------------------------------------------------------------\n");
            printf("Press 1 to make shapes\n");
            printf("Press 2 to draw on terminal\n");
            printf("Press 3 to save the file\n");
            printf("Press 4 to view existing file\n");
            printf("Press 5 to edit an existing file\n");
            printf("Press q to quit\n");
            scanf("%d", &option);
            continue;
        }
    }
}
#ifndef BRAIN_HEADER_FILE
#define BRAIN_HEADER_FILE

#include "..\data\data_header.h"
#include "brain.h"

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include <windows.h>
#include <stdlib.h>

#endif

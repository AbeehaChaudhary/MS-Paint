//////shapes functions
void square_functions(int fill_type, int size, int outlineColorChoice, int fillColorChoice, char character, int position);
void pentagon_functions(int shape_type, int fill_type, int size, int outlineColorChoice, int fillColorChoice, char character, int position);
void chatbox_functions(int fill_type, int size, int outlineColorChoice, int fillColorChoice, char character, int position);
void alphabets_functions(char alpha, int size, int outline_color_choice, char character, int position);
void parallelogram_functions(int fill_type, int size, int outline_color_choice, int fill_color_choice, char character, int position);
void rectangle_functions(int fill_type, int size, int outline_color_choice, int fill_color_choice, char character, int position);
void hexagon_functions(int fill_type, int size, int outline_color_choice, int fill_color_choice, char character, int position);
void numbers_functions(int num, int size, int outline_color_choice, char character, int position);
void hut_functions(int fill_type, int size, int outline_color_choice, char character, int position);
void triangle_functions(int shape_type, int fill_type, int size, int outline_color_choice, int fill_color_choice, char character, int position);
void arrows_functions(int shape_type, int fill_type, int size, int outline_color_choice, int fill_color_choice, char character, int position);
void oval_functions(int fill_type, int size, int outline_color_choice, char character, int position);
void diamond_functions(int shape_type, int fill_type, int size, int outline_color_choice, int fill_color_choice, char character, int position);
void kite_functions(int fill_type, int size, int outline_color_choice, int fill_color_choice, char character, int position);
void trapezium_functions(int shape_type, int fill_type, int size, int outline_color_choice, int fill_color_choice, char character, int position);
void line_functions(int shape_type, int size, int outline_color_choice, char character, int position);
void heart_functions(int fill_type, int size, int outline_color_choice, int fill_color_choice, char character, int position);
void freehand_drawing_functions(int outline_color_choice, char character);
#include "brain_header.h"
////// square 
void square_functions(int fill_type, int size, int outline_color_choice, int fill_color_choice, char character, int position)
{
    if (fill_type == 1)
    {
        filled_square(size, outline_color_choice, fill_color_choice, character, position);
    }
    else if (fill_type == 0)
    {
        hollow_square(size, outline_color_choice, character, position);
    }
    else
    {
        printf("Enter a valid number.");
    }
}
////// heart
void heart_functions(int fill_type, int size, int outline_color_choice, int fill_color_choice, char character, int position)
{
    if (fill_type == 1)
    {
        filled_heart(size, outline_color_choice, fill_color_choice, character, position);
    }
    else if (fill_type == 0)
    {
        hollow_heart(size, outline_color_choice, character, position);
    }

    else
    {
        printf("Enter a valid number.");
    }
}
////// line
void line_functions(int shape_type, int size, int outline_color_choice, char character, int position)
{
    if (shape_type == 1)
    {
        horizontal_line(size, outline_color_choice, character, position);
    }
    else if (shape_type == 0)
    {
        vertical_line(size, outline_color_choice, character, position);
    }
    else
    {
        printf("Enter a valid number.");
    }
}
//////line
void diamond_functions(int shape_type, int fill_type, int size, int outline_color_choice, int fill_color_choice, char character, int position)
{
    if (shape_type == 1)
    {

        if (fill_type == 1)
        {
            simple_filled_diamond(size, outline_color_choice, fill_color_choice, character, position);
        }
        else if (fill_type == 0)
        {
            simple_hollow_diamond(size, outline_color_choice, character, position);
        }
        else
        {
            printf("Enter a valid number.");
        }
    }
    else if (shape_type == 0)
    {

        if (fill_type == 1)
        {
            half_filled_diamond(size, outline_color_choice, fill_color_choice, character, position);
        }
        else if (fill_type == 0)
        {
            half_hollow_diamond(size, outline_color_choice, character, position);
        }
        else
        {
            printf("Enter a valid number.");
        }
    }
    else
    {
        printf("Enter a valid number.");
    }
}
////// kite
void kite_functions(int fill_type, int size, int outline_color_choice, int fill_color_choice, char character, int position)
{
    if (fill_type == 1)
    {
        filled_kite(size, outline_color_choice, fill_color_choice, character, position);
    }
    else if (fill_type == 0)
    {
        hollow_kite(size, outline_color_choice, character, position);
    }
    else
    {
        printf("Enter a valid number.");
    }
}
////// arrows
void arrows_functions(int shape_type, int fill_type, int size, int outline_color_choice, int fill_color_choice, char character, int position)
{
    if (shape_type == 1)
    {
        if (fill_type == 1)
        {
            filled_up_arrow(size, outline_color_choice, fill_color_choice, character, position);
        }
        else if (fill_type == 0)
        {
            hollow_up_arrow(size, outline_color_choice, character, position);
        }
        else
        {
            printf("Enter a valid number.");
        }
    }
    else if (shape_type == 2)
    {
        if (fill_type == 1)
        {
            filled_downward_arrow(size, outline_color_choice, fill_color_choice, character, position);
        }
        else if (fill_type == 0)
        {
            hollow_downward_arrow(size, outline_color_choice, character, position);
        }
        else
        {
            printf("Enter a valid number.");
        }
    }
    else if (shape_type == 3)
    {
        if (fill_type == 1)
        {
            filled_left_arrow(size, outline_color_choice, fill_color_choice, character, position);
        }
        else if (fill_type == 0)
        {
            hollow_left_arrow(size, outline_color_choice, character, position);
        }
        else
        {
            printf("Enter a valid number.");
        }
    }
    else if (shape_type == 4)
    {
        if (fill_type == 1)
        {
            filled_right_arrow(size, outline_color_choice, fill_color_choice, character, position);
        }
        else if (fill_type == 0)
        {
            hollow_right_arrow(size, outline_color_choice, character, position);
        }
        else
        {
            printf("Enter a valid number.");
        }
    }
    else
    {
        printf("Enter a valid number.");
    }
}
////// hut
void hut_functions(int fill_type, int size, int outline_color_choice, char character, int position)
{
    if (fill_type == 1)
    {
        filled_hut(size, outline_color_choice, character, position);
    }
    else
    {
        printf("Enter a valid number.");
    }
}
////// oval
void oval_functions(int fill_type, int size, int outline_color_choice, char character, int position)
{
    if (fill_type == 1)
    {
        filled_oval(size, outline_color_choice, character, position);
    }
    else if (fill_type == 0)
    {
        hollow_oval(size, outline_color_choice, character, position);
    }
    else
    {
        printf("Enter a valid number.");
    }
}
////// hexagon
void hexagon_functions(int fill_type, int size, int outline_color_choice, int fill_color_choice, char character, int position)
{
    if (fill_type == 1)
    {
        filled_hexagon(size, outline_color_choice, fill_color_choice, character, position);
    }
    else if (fill_type == 0)
    {
        hollow_hexagon(size, outline_color_choice, character, position);
    }
    else
    {
        printf("Enter a valid number.");
    }
}
////// pentagon
void pentagon_functions(int shape_type, int fill_type, int size, int outline_color_choice, int fill_color_choice, char character, int position)
{
    if (shape_type == 1)
    {
        if (fill_type == 1)
        {
            simple_filled_pentagon(size, outline_color_choice, fill_color_choice, character, position);
        }
        else if (fill_type == 0)
        {
            simple_hollow_pentagon(size, outline_color_choice, character, position);
        }
        else
        {
            printf("Enter a valid number.");
        }
    }
    else if (shape_type == 0)
    {
        if (fill_type == 1)
        {
            inverted_filled_pentagon(size, outline_color_choice, fill_color_choice, character, position);
        }
        else if (fill_type == 0)
        {
            inverted_hollow_pentagon(size, outline_color_choice, character, position);
        }
        else
        {
            printf("Enter a valid number.");
        }
    }
    else
    {
        printf("Enter a valid number.");
    }
}
////// trapezium
void trapezium_functions(int shape_type, int fill_type, int size, int outline_color_choice, int fill_color_choice, char character, int position)
{
    if (shape_type == 1)
    {
        if (fill_type == 1)
        {
            simple_filled_trapezium(size, outline_color_choice, fill_color_choice, character, position);
        }
        else if (fill_type == 0)
        {
            simple_hollow_trapezium(size, outline_color_choice, character, position);
        }
        else
        {
            printf("Enter a valid number.");
        }
    }
    else if (shape_type == 0)
    {
        if (fill_type == 1)
        {
            inverted_filled_trapezium(size, outline_color_choice, fill_color_choice, character, position);
        }
        else if (fill_type == 0)
        {
            inverted_hollow_trapezium(size, outline_color_choice, character, position);
        }
        else
        {
            printf("Enter a valid number.");
        }
    }
    else
    {
        printf("Enter a valid number.");
    }
}
////// triangle
void triangle_functions(int shape_type, int fill_type, int size, int outline_color_choice, int fill_color_choice, char character, int position)
{
    if (shape_type == 1)
    {
        if (fill_type == 1)
        {
            simple_filled_triangle(size, outline_color_choice, fill_color_choice, character, position);
        }
        else if (fill_type == 0)
        {
            simple_hollow_triangle(size, outline_color_choice, character, position);
        }
        else
        {
            printf("Enter a valid number.");
        }
    }
    else if (shape_type == 0)
    {
        if (fill_type == 1)
        {
            inverted_filled_triangle(size, outline_color_choice, fill_color_choice, character, position);
        }
        else if (fill_type == 0)
        {
            inverted_hollow_triangle(size, outline_color_choice, character, position);
        }
        else
        {
            printf("Enter a valid number.");
        }
    }
    else
    {
        printf("Enter a valid number.");
    }
}
////// chatbox
void chatbox_functions(int fill_type, int size, int outline_color_choice, int fill_color_choice, char character, int position)
{
    if (fill_type == 1)
    {
        filled_chatbox(size, outline_color_choice, fill_color_choice, character, position);
    }
    else if (fill_type == 0)
    {
        hollow_chatbox(size, outline_color_choice, character, position);
    }
    else
    {
        printf("Enter a valid number.");
    }
}
////// parallelogram
void parallelogram_functions(int fill_type, int size, int outline_color_choice, int fill_color_choice, char character, int position)
{
    if (fill_type == 1)
    {
        filled_parallelogram(size, outline_color_choice, fill_color_choice, character, position);
    }
    else if (fill_type == 0)
    {
        hollow_parallelogram(size, outline_color_choice, character, position);
    }
    else
    {
        printf("Enter a valid number.");
    }
}
////// rectangle
void rectangle_functions(int fill_type, int size, int outline_color_choice, int fill_color_choice, char character, int position)
{
    if (fill_type == 1)
    {
        filled_rectangle(size, outline_color_choice, fill_color_choice, character, position);
    }
    else if (fill_type == 0)
    {
        hollow_rectangle(size, outline_color_choice, character, position);
    }
    else
    {
        printf("Enter a valid number.");
    }
}
////// alphabets
void alphabets_functions(char alpha, int size, int outline_color_choice, char character, int position)
{
    if (alpha == 'a')
    {
        alphabetA(size, outline_color_choice, character, position);
    }
    else if (alpha == 'b')
    {
        alphabetB(size, outline_color_choice, character, position);
    }
    else if (alpha == 'c')
    {
        alphabetC(size, outline_color_choice, character, position);
    }
    else if (alpha == 'd')
    {
        alphabetD(size, outline_color_choice, character, position);
    }
    else if (alpha == 'e')
    {
        alphabetE(size, outline_color_choice, character, position);
    }
    else if (alpha == 'f')
    {
        alphabetF(size, outline_color_choice, character, position);
    }
    else if (alpha == 'g')
    {
        alphabetG(size, outline_color_choice, character, position);
    }
    else if (alpha == 'h')
    {
        alphabetH(size, outline_color_choice, character, position);
    }
    else if (alpha == 'i')
    {
        alphabetI(size, outline_color_choice, character, position);
    }
    else if (alpha == 'j')
    {
        alphabetJ(size, outline_color_choice, character, position);
    }
    else if (alpha == 'k')
    {
        alphabetK(size, outline_color_choice, character, position);
    }
    else if (alpha == 'l')
    {
        alphabetL(size, outline_color_choice, character, position);
    }
    else if (alpha == 'm')
    {
        alphabetM(size, outline_color_choice, character, position);
    }
    else if (alpha == 'n')
    {
        alphabetN(size, outline_color_choice, character, position);
    }
    else if (alpha == 'o')
    {
        alphabetO(size, outline_color_choice, character, position);
    }
    else if (alpha == 'p')
    {
        alphabetP(size, outline_color_choice, character, position);
    }
    else if (alpha == 'q')
    {
        alphabetQ(size, outline_color_choice, character, position);
    }
    else if (alpha == 'r')
    {
        alphabetR(size, outline_color_choice, character, position);
    }
    else if (alpha == 's')
    {
        alphabetS(size, outline_color_choice, character, position);
    }
    else if (alpha == 't')
    {
        alphabetT(size, outline_color_choice, character, position);
    }
    else if (alpha == 'u')
    {
        alphabetU(size, outline_color_choice, character, position);
    }
    else if (alpha == 'v')
    {
        alphabetV(size, outline_color_choice, character, position);
    }
    else if (alpha == 'w')
    {
        alphabetW(size, outline_color_choice, character, position);
    }
    else if (alpha == 'x')
    {
        alphabetX(size, outline_color_choice, character, position);
    }
    else if (alpha == 'y')
    {
        alphabetY(size, outline_color_choice, character, position);
    }
    else if (alpha == 'z')
    {
        alphabetZ(size, outline_color_choice, character, position);
    }
}
////// numbers
void numbers_functions(int num, int size, int outline_color_choice, char character, int position)
{
    if (num == 0)
    {
        number0(size, outline_color_choice, character, position);
    }
    else if (num == 1)
    {
        number1(size, outline_color_choice, character, position);
    }
    else if (num == 2)
    {
        number2(size, outline_color_choice, character, position);
    }
    else if (num == 3)
    {
        number3(size, outline_color_choice, character, position);
    }
    else if (num == 4)
    {
        number4(size, outline_color_choice, character, position);
    }
    else if (num == 5)
    {
        number5(size, outline_color_choice, character, position);
    }
    else if (num == 6)
    {
        number6(size, outline_color_choice, character, position);
    }
    else if (num == 7)
    {
        number7(size, outline_color_choice, character, position);
    }
    else if (num == 8)
    {
        number8(size, outline_color_choice, character, position);
    }
    else if (num == 9)
    {
        number9(size, outline_color_choice, character, position);
    }
}
////// freehand drawing
void freehand_drawing_functions(int outline_color_choice, char character)
{
    int x = 30, y = 10;
    char key;
    gotoxy(x, y);

    while (1) // using while infinity loop
    {
        key = getch();
        if (key == 75) // left arrow key
        {
            x--;
        }
        else if (key == 77) // right arrow key
        {
            x++;
        }
        else if (key == 72) // up arrow key
        {
            y--;
        }
        else if (key == 80) // down arrow key
        {
            y++;
        }
        else if (key == 8 || key == 75 || key == 77 || key == 72 || key == 80) // backspace and arrow keys
        {
            printf(" ");
        }
        else if (key == 32 || key == 75 || key == 77 || key == 72 || key == 80) // spacebar and arrow keys
        {
            changeTextColor(outline_color_choice);
            printf("%c", character);
        }
        gotoxy(x, y); // storing value in this gotoxy after increement or decreement
    }
    getch();
}
